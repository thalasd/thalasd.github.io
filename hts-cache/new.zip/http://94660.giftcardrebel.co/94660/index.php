<!doctype html>
<html>
<head>

  <meta charset="utf-8"/>
  <title>Free Gift Cards</title>
    
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  
  <meta name="theme-color" content="#52555b">
  <link rel="icon" sizes="192x192" href="http://i.imgur.com/gih1Rf7.png">
    
  <meta name="author" content="Gift Card Rebel"/>
  <meta name="description" content="Gift Card Rebel is best way to get Free Gift Cards. Now you can get all of your favorite apps and games for free."/>
    
  <meta property="og:description" content="Gift Card Rebel is best way to get Free Gift Cards. Now you can get all of your favorite apps and games for free."/>
  
  <meta property="og:site_name" content="GetGiftCards"/>
  <meta property="og:title" content="Free Gift Cards"/>
  <meta property="og:type" content="website"/>
  <meta property="og:url" content="http://getgiftcards.org/"/>
    
  <link href='http://fonts.googleapis.com/css?family=Oswald:700' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
    <style>
  * { position: relative; margin: 0; padding: 0; border: none; outline: none; font-family: 'Open Sans', sans-serif; font-weight: 400; }
* { -webkit-touch-callout: none; -webkit-user-select: none; -khtml-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; cursor: default; }
a img { border: none; outline: none; }
a { text-decoration: none; }
ul, li { list-style: none; }
.clear { clear: both; }

html, body { overflow-y: scroll; }
body { min-width: 1000px; height: auto; overflow: hidden; background: #52555b; }

iframe { display: none; }

#wrapper { overflow: hidden; z-index: 3; }
#wrapper.loaded { transition: all 500ms ease; }
#wrapper.hidden { opacity: 0.1 !important; transform: scale(0.95) !important; }
#inner { transition: all 500ms ease; transform-origin: 50% 20%; }
#inner.hidden { opacity: 0.1; transform: scale(0.95) !important; }

#background { position: absolute; width: 1180px; height: 3540px; top: 0; left: 50%; margin-left: -590px; overflow: hidden; }
#background svg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }

#menu-trigger { width: 32px; height: 30px; position: absolute; top: 40px; left: 50%; margin-left: -420px; cursor: pointer; z-index: 5; }
.menu-trigger { display: block; position: absolute; width: 32px; height: 4px; margin-top: -2px; background: #1f2227; top: 50%; left: 0; transition: all 400ms; }
.menu-trigger:nth-child(1) { top: 6px; }
.menu-trigger:nth-child(3) { top: 24px; }
#menu-trigger.close .menu-trigger:nth-child(1) { top: 50%; transform: rotateZ(45deg); }
#menu-trigger.close .menu-trigger:nth-child(3) { top: 50%; transform: rotateZ(-45deg); }
#menu-trigger.close .menu-trigger:nth-child(2) { opacity: 0; }
#menu-trigger, #menu-trigger * { cursor: pointer; }

#menu { position: absolute; left: 0; top: 0; width: 100%; height: 0; z-index: 4; opacity: 0; overflow: hidden; }
#menu ul { position: absolute; top: 0; left: 50%; transform: translateX(-50%); text-align: center; padding: 100px 0; }
#menu ul li { display: block; margin: 30px; }
.menu { cursor: pointer; display: block; font-family: 'Oswald', sans-serif; font-weight: 700; color: #fff; text-transform: uppercase; font-size: 32px; text-shadow: 3px 3px rgba(0,0,0,0.3); }

#sky { position: absolute; top: -500px; left: -500px; right: -500px; height: 1080px; background: rgba(255,255,255,0.1); }

#header { width: 870px; margin: 0 auto; box-sizing: border-box; padding: 40px 0 0 400px; height: 500px; }
#logo { display: block; width: 350px; height: 78px; margin: 0 auto; }
#logo, #logo * { cursor: pointer; }
#intro { width: 100%; padding-top: 40px; text-align: center; text-shadow: 5px 5px rgba(0, 0, 0, 0.3); color: #fff; text-transform: uppercase; }
#intro1 { display: block; color: #fff; font-size: 40px; font-family: 'Oswald', sans-serif; line-height: 42px; }
#intro2, h1 { display: inline; font-family: 'Oswald', sans-serif; font-weight: 700; font-size: 68px; line-height: 70px; }

#scrolldown { position: absolute; width: 54px; height: 30px; left: 50%; margin-left: -27px; bottom: -70px; }
#scrolldown svg { position: absolute; top: 0; left: 0; width: 100%; height: 100%; animation: bounce 0.4s ease-in-out infinite alternate; }
@keyframes bounce { from { transform: translateY(0px); } to { transform: translateY(10px); } }
@-webkit-keyframes bounce { from { transform: translateY(0px); } to { transform: translateY(10px); } }

#page { width: 980px; margin: 0 auto; box-sizing: border-box; padding: 90px 140px 150px 460px; }
#page > h2 { font-family: 'Oswald', sans-serif; font-weight: 700; font-size: 36px; color: #FFF; text-shadow: 2px 2px #23262b; margin: 0 0 25px; text-align: center; text-transform: uppercase; }

#home { width: 104%; margin-left: -2%; }
.home-card { float: left; width: 30%; height: 0; padding-top: 42.5%; margin-right: 5%; margin-bottom: 5%; cursor: pointer; transform-origin: 50% 0; display: block; }
.home-card:nth-child(3n) { margin-right: 0; }
.home-card-title { display: none; }
.home-card svg { width: 100%; height: 100%; }
.home-card-front { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 2; transition: all 400ms ease; }
.home-card-logo { position: absolute; top: 0; left: 0; width: 100%; height: 100%; padding-top: 5%; }
.home-card-back { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; transform: translateX(1px) translateY(1px); transition: all 400ms ease; }
.home-card:hover .home-card-front { transform: translateY(-3px); }
.home-card, .home-card * { cursor: pointer; }

#content p { color: #23262B; font-size: 18px; line-height: 26px; font-weight: 400; text-align: justify; font-family: 'Open Sans', sans-serif; letter-spacing: 0.2px; }
#content p+p { margin-top: 10px; }
#content h2 { text-align: center; font-size: 24px; font-weight: 700; line-height: 30px; color: #FFF; text-shadow: 2px 2px #23262b; margin: 30px 0 15px; font-family: 'Open Sans', sans-serif; letter-spacing: 0.5px; }

#cards { width: 104%; margin-left: -2%; height: 0; padding-bottom: 45%; }
.gcard { float: left; width: 30%; height: 0; padding-top: 42.5%; margin-right: 5%; cursor: pointer; transform-origin: 50% 0; }
.gcard svg { width: 100%; height: 100%; }
.gcard:nth-child(3n) { margin-right: 0; }
.gcard-front { position: absolute; left: 0; top: 0; width: 100%; height: 100%; z-index: 2; transition: all 400ms ease; }
.gcard-back { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1; transform: translateX(1px) translateY(1px); transition: all 400ms ease; }
.gcard:hover .gcard-front { transform: translateY(-3px); }
.gcard-logo { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
.gcard-value { position: absolute; z-index: 2; right: 9px; bottom: 7px; color: #fff; font-size: 16px; font-weight: 600; }
.gcard, .gcard * { cursor: pointer; }

/* POPUP WINDOW */

#gboverlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; display: none; z-index: 6; perspective: 1200px; overflow: hidden; transition: transform 150ms; }
#gboverlay.noclick { transform: scale(1.02); }
#gbclose { position: absolute; left: 50%; top: 50%; width: 50px; height: 50px; margin-left: -25px; margin-top: -25px; opacity: 0; transition: opacity 400ms; z-index: 1; }
#gbclose.show { opacity: 1; }
#gbmouse { position: absolute; left: 0; top: 0; width: 100%; height: 100%; z-index: 2; }
#gbmouse.nomouse { cursor: none; }
#generatorbox { position: absolute; top: 50%; left: 50%; width: 640px; height: 400px; margin-left: -320px; margin-top: -200px; background: #fff; border-radius: 15px; z-index: 3; opacity: 0;
transform: scale(1.3) rotateX(10deg); transition: transform 400ms, opacity 400ms, height 400ms, margin-top 400ms, top 400ms; }
#generatorbox.show { opacity: 1; transform: scale(1) rotateX(0); }
#generatorbox.big { height: 450px; margin-top: -225px; }
#gbinner { position: absolute; top: 35px; bottom: 35px; left: 40px; right: 40px; /*opacity: 0; transition: opacity 300ms;*/ }
#gbinner.show { opacity: 1; }
#hacklines { display: none; }
#steps { position: relative; height: 65px; }
.stepname { position: absolute; top: 0; font-size: 18px; line-height: 18px; color: #BDC3C7; width: 100%; transition: color 600ms; }
#step1 { text-align: left; } #step2 { text-align: center; } #step3 { text-align: right; }
#statusbar { position: absolute; left: 11px; right: 11px; height: 6px; background: #BDC3C7; top: 45px; }
.sbcirc { position: absolute; top: -8px; height: 22px; width: 22px; border-radius: 11px; background: #BDC3C7; }
#sbcirc2 { left: 50%; margin-left: -11px; } #sbcirc3 { right: -11px; } #sbcirc1 { left: -11px; }
#sbcomplete { position: absolute; z-index: 1; left: 0; top: 0; height: 6px; border-radius: 3px; width: 0; }
.sbcirca { position: absolute; height: 14px; width: 14px; border-radius: 7px; top: -4px; transition: background 300ms, transform 300ms cubic-bezier(0.175, 0.885, 0.32, 1.275); z-index: 2; transform: scale(0); }
.sbcirca.active { transform: scale(1); }
#sbcirca2 { left: 50%; margin-left: -7px; } #sbcirca3 { right: -7px; } #sbcirca1 { left: -7px; }
#statustext { position: absolute; color: #BDC3C7; left: 0; width: 100%; bottom: 0; font-size: 20px; line-height: 18px; text-align: center; transition: color 800ms; }
#statustext.final { color: #E74C3C; }
#genlogo { position: absolute; top: 90px; left: 50%; margin-left: -115px; width: 240px; height: 196px; transition: opacity 600ms; }
#genlogo.hide { opacity: 0; }
#genreturn { position: absolute; bottom: 30px; height: 40px; line-height: 40px; letter-spacing: 1.2px; left: -40px; right: -40px; color: #BDC3C7; text-align: center; font-size: 35px; white-space: nowrap; opacity: 0; transition: opacity 600ms; }
#genreturn.active { opacity: 1; }
#genreturn span { color: #BDC3C7; transition: color 800ms; }
#widgetholder { position: absolute; overflow: hidden; width: 560px; height: 210px; top: 85px; left: 0; background: #ECF0F1; border-radius: 5px; opacity: 0; z-index: 2; transition: opacity 600ms; }
#widgetholder.show { opacity: 1; }
#whclick { position: absolute; width: 560px; height: 210px; top: 0; left: 0; z-index: 2; }
#widgetholder.show #whclick { display: none; }
#whcontent { position: absolute; width: 560px; height: 210px; left: 0; overflow: hidden; z-index: 1; }
#whdesc { position: absolute; top: 0; left: 0; width: 460px; z-index: 2; height: 44px; line-height: 20px; padding: 12px 50px 10px; background: #ECF0F1; color: #23262B; text-align: center; font-size: 16px; letter-spacing: 0.2px; }

.xbox #genreturn { letter-spacing: 0 !important; font-size: 33px !important; }


/* -------------- MOBILE WEBSITE  --------------*/

@media only screen and (max-width: 768px) {

body { min-width: 0; }

#sky { top: -50vw; left: -50vw; right: -50vw; height: 150vw; }
#background { width: 205vw; height: 615vw; left: -22.5vw; margin-left: 0; top: 50vw; }

#menu-trigger { top: 10vw; left: auto; margin-left: 0; right: 7vw; }
#menu ul { padding: 30vw 10vw; left: 0; transform: translateX(0); width: 100%; box-sizing: border-box; }
#menu ul li { margin: 0 0 4vw; }
.menu { font-size: 7vw; text-shadow: 1vw 1vw rgba(0,0,0,0.3); }

#header { width: 100vw; padding: 7vw 10vw 0; height: auto; position: absolute; top: 0; z-index: 2; }
#logo { width: 65vw; height: 14.7vw; margin: 0; }
#intro { padding-top: 5vw; text-align: left; text-shadow: 1vw 1vw rgba(0,0,0,0.3); letter-spacing: 0.1vw; }
#intro1 {font-size: 9vw; line-height: 12vw; }
#intro2, #intro h1 {font-size: 10vw; line-height: 12vw; }
#scrolldown { display: none; }

#page { width: 100vw; padding: 150vw 10vw 20vw 24vw; margin: 0; z-index: 1; }
#page > h2 { font-size: 7vw; margin-bottom: 4vw; }
#home { width: 100%; margin: 0; }

.home-card { float: left; width: 30vw; height: 0; padding-top: 42.5vw; margin: 0; margin-bottom: 5vw; margin-right: 5.5vw; }
.home-card:nth-child(2n) { margin-right: 0; }
.home-card:nth-child(2n+1) {margin-right: 5.5vw; }

#cards { width: 100%; margin-left: 0; height: auto; padding-bottom: 0; }
.gcard { float: none; width: 30vw; height: 0; padding-top: 42.5vw; margin: 0 auto 3vw !important; }
#content h2 { font-size: 5vw; line-height: 6.5vw; margin: 7vw 0 4vw; }
#content p { font-size: 4vw; line-height: 5.4vw; letter-spacing: 0.1vw; }
#content p+p { margin-top: 4vw; }

#generatorbox { width: 90vw; height: 110vw; top: 50%; left: 50%; margin-top: -55vw !important; margin-left: -45vw !important; border-radius: 2vw; }
#generatorbox.big { height: 140vw !important; margin-top: -70vw !important; }
#gbinner { top: 7vw; bottom: 7vw; left: 6vw; right: 6vw; }
#steps { height: 15%; }
.stepname { font-size: 4vw; }
#statusbar { left: 3vw; right: 3vw; height: 2vw; top: 75%; }
#sbcomplete { height: 2vw; border-radius: 1vw; }
.sbcirc { height: 6.115vw; width: 6.115vw; border-radius: 100%; top: -2.2vw; }
#sbcirc1 { left: -3.05vw; }
#sbcirc2 { margin-left: -3.05vw; }
#sbcirc3 { right: -3.05vw; }
.sbcirca { width: 3.75vw; height: 3.75vw; border-radius: 100%; top: -1vw; }
#sbcirca3 { right: -1.875vw; }
#sbcirca2 { margin-left: -1.875vw; }
#sbcirca1 { left: -1.875vw; }

#statustext { font-size: 3.5vw; line-height: 4.5vw; white-space: nowrap; overflow: hidden; letter-spacing: 0; }
#genreturn { bottom: 6%; width: 100%; left: 0; right: 0; white-space: normal; height: 17%; letter-spacing: 0 !important; font-size: 8vw !important; line-height: 10vw; }
#genlogo { width: 64vw; height: 58.5vw; margin-left: -32vw; top: 24%; background-size: 100% auto; }

#widgetholder { width: 100%; height: 67vw; top: 26vw; border-radius: 1vw; }

.xbox #genreturn { letter-spacing: 0 !important; font-size: 7.4vw !important; }

} /* END OF MOBILE WEBSITE */
  </style>
    
</head>
<body color="#52555b" class="" style="background-color: #52555b;" oncontextmenu="return false">

  <div id="menu">
    <ul>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=googleplay" class="menu">Google Play</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=xbox" class="menu">Xbox</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=steam" class="menu">Steam</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=microsoft" class="menu">Microsoft</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=playstation" class="menu">PlayStation Store</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=itunes" class="menu">iTunes</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=skype" class="menu">Skype</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=windows" class="menu">Windows</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=ebay" class="menu">eBay</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=paypal" class="menu">PayPal</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=amazon" class="menu">Amazon</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=facebook" class="menu">Facebook</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=netflix" class="menu">Netflix</a></li>
<li><a href="http://94660.giftcardrebel.co/94660/index.php?card=spotify" class="menu">Spotify</a></li>
    </ul>
  </div>

  <div id="menu-trigger">
    <div class="menu-trigger"></div>
    <div class="menu-trigger"></div>
    <div class="menu-trigger"></div>
  </div>

  <div id="wrapper">  <div id="inner">
    <script type="text/javascript">
      document.getElementById('wrapper').style.opacity = '0';
      document.getElementById('menu-trigger').style.opacity = '0';
    </script>

    <div id="sky"></div>

    <div id="background"><svg width="100%" height="100%" version="1.0" viewBox="0 0 13889 41667" preserveAspectRatio="none" style="fill-rule:evenodd; clip-rule:evenodd">
 <defs><style type="text/css"><![CDATA[.str0 {stroke:#373435;stroke-width:0.0393701} .bkcfil12 {fill:none} .bkcfil11 {fill:#161A1C} .bkcfil9 {fill:#191D20} .bkcfil8 {fill:#1F2227} .bkcfil1 {fill:#2A2D34} .bkcfil13 {fill:#2C3E50} .bkcfil10 {fill:#33353B} .bkcfil2 {fill:#3F4248} .bkcfil6 {fill:#657071} .bkcfil3 {fill:#7F8C8D} .bkcfil7 {fill:#BB8481} .bkcfil5 {fill:#D8C0A6} .bkcfil4 {fill:#F0D6B9} ]]> #Closed {display: none;}</style></defs>
 <g id="Opened">
  <g id="_1387123740432">
   <path class="bkcfil1" d="M5709 4485c2464,535 2174,1795 6101,1951l0 35231 -5707 0 0 -29180 -325 0 0 -7369 -261 -39 -79 -96 271 -498z"/>
   <path class="bkcfil2" d="M5744 4421c2464,535 2139,1829 6066,1984l0 62c-3927,-156 -3672,-1383 -6136,-1917l0 0 70 -129z"/>
   <path class="bkcfil3" d="M5438 4983c1725,0 2557,1613 5995,1613l0 35071 -5330 0 0 -29180 -325 0 0 -6848 -340 -656z"/>
   <path class="bkcfil4" d="M11870 7400l8 1c80,7 140,79 133,160l0 0c-8,81 -79,141 -160,133l-432 -39c-81,-7 -141,-79 -133,-160l0 0c4,-45 28,-83 62,-107 -66,-22 -114,-84 -113,-157l0 0c1,-63 37,-117 89,-144 -62,-26 -108,-86 -112,-158l0 0c-4,-79 44,-149 113,-177 -47,-25 -80,-71 -87,-126l0 0c-10,-90 55,-171 145,-181l478 -53c90,-10 171,55 181,144l0 0c9,81 -43,154 -118,176 96,-2 178,74 183,172l0 0c5,99 -73,184 -172,189l-34 2c81,11 143,81 142,164l0 0c-1,90 -75,162 -165,162l-8 -1z"/>
   <path class="bkcfil5" d="M11550 7519c3,-29 8,-59 18,-86 -65,-10 -129,-26 -192,-47 34,17 103,40 175,57 -7,23 -11,51 -13,75 -2,24 -3,52 -1,76 -73,4 -146,14 -182,25 66,-10 131,-14 197,-12 -5,-29 -5,-59 -2,-88zm-20 -285c0,-33 3,-66 12,-97 -73,-5 -145,-17 -217,-36 39,16 118,36 199,48 -5,26 -8,58 -8,84 0,27 2,59 6,85 -81,10 -160,28 -200,43 72,-16 145,-27 218,-31 -8,-31 -11,-64 -10,-96zm8 -322c-2,-35 -1,-73 7,-107 -81,-1 -161,-10 -242,-25 45,15 133,31 223,39 -4,29 -4,65 -3,94 2,29 6,64 13,93 -89,17 -175,42 -218,61 78,-23 158,-39 238,-49 -11,-33 -16,-70 -18,-106zm-7 -319c-3,-32 -4,-65 1,-97 -73,3 -147,0 -220,-9 41,11 122,21 204,23 -3,27 -1,58 2,85 3,26 8,57 16,83 -79,20 -155,47 -193,67 69,-25 140,-44 212,-57 -12,-30 -18,-63 -22,-95z"/>
   <path class="bkcfil6" d="M6425 5288c-10,0 -19,12 -28,33l20 51 46 -25c-12,-38 -24,-59 -38,-59zm-78 730c11,215 42,371 78,371 34,0 62,-132 76,-322l-71 -111 -83 62z"/>
  </g>
 </g>
 <g id="Body">
  <g id="_1387123743152">
   <polygon class="bkcfil4" points="5280,1349 3834,1813 3003,2612 2701,3464 3111,4015 3467,4468 3637,4678 4285,4787 4914,4678 5042,4414 5733,3809 5884,3421 5485,2374 "/>
   <path class="bkcfil7" d="M4287 4352c-138,-66 -305,67 -485,18l0 0c151,-21 279,-76 366,-189 34,26 71,49 119,49 47,0 84,-23 118,-49 88,113 215,168 367,189l0 0c-180,49 -347,-84 -485,-18z"/>
   <path class="bkcfil8" d="M3406 5253c-163,96 -276,53 -429,-77 230,-232 153,-452 69,-532 24,207 -43,264 -76,370 -485,-334 -574,-691 -329,-1135 -147,14 -270,-11 -313,-143 157,84 256,65 414,-90 -146,2 -300,6 -461,35 747,-412 324,-946 558,-1794 87,-313 312,-577 586,-762 529,-359 1027,-348 1379,17 740,-219 907,387 952,983 48,630 -88,1162 529,1564 -149,7 -297,-3 -443,-32 129,142 231,136 410,86 -82,118 -154,155 -291,157 192,502 51,820 -383,1138 -177,107 -179,142 -445,251l-1727 -36zm806 -2327c-24,-195 -292,-207 -461,-207 -311,0 -450,82 -477,299l-89 0c-8,-77 -13,-154 -11,-238 396,-808 1304,-525 1802,-1160 562,246 222,865 389,1290 -1,36 -3,72 -4,108l-96 0c-27,-217 -166,-299 -477,-299 -169,0 -437,12 -461,207l-115 0zm-1020 149l77 0c0,10 0,20 0,31 0,268 128,457 355,457 261,0 568,-307 589,-580l114 0c20,273 327,580 588,580 227,0 355,-189 355,-457 0,-11 0,-21 0,-31l88 0c-6,151 -13,299 -20,444 75,-88 143,-210 200,-377 49,90 130,152 237,188 -138,416 -279,550 -424,428 0,234 -88,422 -408,488 -41,-204 -248,-306 -656,-286 -409,-20 -615,82 -657,286 -332,-68 -414,-269 -407,-516 -127,158 -265,68 -421,-400 88,-38 171,-98 248,-183 31,156 99,282 184,394 -1,-182 -25,-325 -42,-466zm1095 1384c-75,0 -150,0 -225,0 155,104 192,265 82,238 -277,-67 -418,-170 -377,-340 163,-23 299,-86 393,-214 36,30 76,55 127,55 51,0 90,-25 127,-55 93,128 230,191 392,214 42,170 -99,273 -377,340 -110,27 -72,-134 83,-238 -75,0 -150,0 -225,0z"/>
   <polygon class="bkcfil9" points="2436,12487 6103,12487 6103,41667 2436,41667 2436,13088 2475,13066 2436,13044 "/>
   <path class="bkcfil2" d="M5810 12400l293 -93 0 -6368c132,43 265,85 398,128 4,-70 7,-147 7,-229 0,-214 -18,-400 -45,-491l-1281 -506 -905 307 -920 -307 -921 364c0,2367 0,4735 0,7102l293 93c2061,0 1020,0 3081,0z"/>
   <path class="bkcfil10" d="M6103 12307c-1222,0 -2444,0 -3667,0 -74,0 -74,214 0,214 1223,0 2445,0 3667,0 74,0 74,-214 0,-214z"/>
   <path class="bkcfil11" d="M5364 12521c0,340 165,567 739,567l0 -44c-545,-9 -720,-217 -739,-523zm-2189 0c0,340 -165,567 -739,567l0 -44c545,-9 720,-217 739,-523z"/>
   <path class="bkcfil1" d="M4998 41667l0 -34544c0,-970 -1523,-1328 -1759,-1934l0 0c-61,-174 -94,-311 -111,-477 -226,-2 -503,172 -644,289 -71,59 -96,90 -79,202 -1133,674 -1913,1787 -1919,3019 17,947 494,1951 1592,2833l0 30612 2920 0zm-2888 -35164c-21,316 -32,663 -32,995l0 2440c-517,-543 -746,-1177 -748,-1771 -3,-634 241,-1242 748,-1689l32 25z"/>
   <path class="bkcfil4" d="M2546 11061l-45 1 14 -28c140,-91 265,-203 368,-348l26 7 20 34c-108,141 -239,252 -383,334z"/>
   <path class="bkcfil2" d="M2044 10772c85,-107 289,50 206,155l-164 207 -204 -161 162 -201zm1085 -6058c-3,-28 -5,-57 -7,-88 -226,39 -502,228 -674,371 -68,56 -74,105 -43,206 2,-39 15,-84 57,-119 167,-138 451,-331 667,-370zm-240 5963c19,-29 49,-62 61,-90 -12,-7 -37,-10 -49,-18 -1042,-655 -1549,-1555 -1571,-2402 -23,876 478,1825 1559,2510zm-484 -5474c-1182,641 -1942,1781 -1919,3019 25,-1198 784,-2293 1937,-2913 -7,-35 -9,-70 -18,-106zm760 749c65,-41 166,-89 260,-123 -168,32 -325,93 -577,307 19,41 74,46 130,-13 53,-56 123,-120 187,-171zm74 -763c288,601 1759,907 1759,1934 0,-927 -1665,-1397 -1759,-1934zm134 1202c4,112 51,109 161,92 602,-94 1117,140 1420,554 -309,-395 -848,-599 -1450,-493 -120,21 -154,-8 -131,-153z"/>
   <path class="bkcfil9" d="M4954 7037c-315,-400 -861,-575 -1489,-447 -127,26 -174,29 -166,-128 6,-130 66,-327 187,-554 -93,237 -107,342 -112,471 -7,157 37,154 160,133 602,-106 1117,117 1420,525zm-1789 -1085c-99,87 -185,206 -234,319 -47,107 -126,95 -207,-48 -140,-248 -277,-651 -319,-1020 91,270 216,578 357,827 55,98 121,176 226,65 52,-55 112,-102 177,-143zm-916 387c-100,282 -171,744 -171,1159 0,-340 0,-680 0,-1020 53,-47 113,-96 171,-139zm880 4017c-49,137 -123,267 -200,371l-46 -41 6 -9c19,-29 35,-57 47,-86 -11,-7 -23,-14 -35,-22 76,-69 152,-140 228,-213zm-583 705c-123,69 -260,120 -397,148 21,-17 42,-33 62,-50l9 7c92,-20 195,-68 295,-132l31 27z"/>
   <path class="bkcfil9" d="M2120 10800c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm2665 -3758c46,0 83,36 83,82 0,46 -37,82 -83,82 -45,0 -82,-36 -82,-82 0,-46 37,-82 82,-82zm-891 0c46,0 83,36 83,82 0,46 -37,82 -83,82 -45,0 -82,-36 -82,-82 0,-46 37,-82 82,-82zm891 2030c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm-891 0c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm891 2030c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm-891 0c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm891 2031c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm-891 0c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82z"/>
   <path class="bkcfil13" d="M3995 2738c-25,-5 -51,-9 -77,-12l-370 829c24,5 49,8 76,8 10,0 19,-1 29,-1l342 -824zm-205 -19c-14,0 -26,0 -39,0 -34,0 -65,1 -95,3l-309 693c32,49 74,88 124,113l319 -809zm1188 14l-313 749c60,38 124,64 187,75l276 -773c-41,-24 -90,-41 -150,-51zm205 93l-267 737c22,0 43,-2 63,-6l232 -696c-8,-12 -18,-24 -28,-35z"/>
  </g>
 </g>
 <g id="Closed">
  <g id="_1387123747888">
   <path class="bkcfil1" d="M3681 41667l0 -34544c0,-1039 1400,-1341 1619,-1933l0 0c60,-173 95,-309 111,-474 14,-136 571,233 631,270 69,42 66,78 59,205l-3 18c849,300 2070,1003 2035,1886 -7,165 -50,340 -139,524 -276,573 -874,856 -1533,988l-40 31 -11 104c27,44 51,144 51,572l0 32353 -2780 0zm2715 -35357l59 164 -26 30c21,315 32,557 32,889l0 348c506,-164 799,-440 799,-734 0,-257 -247,-520 -799,-717l-65 20z"/>
   <path class="bkcfil2" d="M5163 6427c-4,111 -43,103 -141,76 -539,-148 -1008,26 -1279,412 281,-358 767,-509 1306,-348 107,32 144,12 114,-140zm248 -1711c3,-28 5,-57 7,-87 220,35 478,208 641,343 62,52 66,75 42,219 -2,-38 -17,-99 -55,-131 -161,-134 -424,-308 -635,-344zm-27 1233c-70,-41 -179,-88 -280,-122 181,31 350,92 622,306 -20,41 -80,46 -141,-13 -56,-55 -132,-120 -201,-171zm-1703 1174c0,-1134 1331,-1332 1619,-1933 -115,587 -1544,846 -1619,1933zm2420 -1932c849,296 2070,939 2032,1904 -32,-925 -1219,-1541 -2045,-1826l13 -78zm-1502 2691l0 -82c1558,219 2605,-266 2659,-760 1,17 2,33 2,50 -10,504 -1068,1016 -2661,792zm492 622c0,-137 -258,-141 -258,-7l0 208 -36 83 325 11 -30 -87 -1 -208z"/>
   <path class="bkcfil9" d="M3743 6915c283,-350 774,-467 1338,-288 115,36 156,42 150,-107 -6,-123 -60,-315 -169,-541 83,233 96,333 101,456 6,149 -33,143 -144,111 -541,-154 -1004,10 -1276,369zm2547 -681c100,282 171,744 171,1159l0 -1103c-54,-19 -111,-38 -171,-56zm-1192 -408c183,99 375,227 479,465 46,107 125,95 206,-49 140,-248 276,-681 318,-1051 -74,350 -183,608 -332,853 -58,96 -93,158 -198,47 -52,-55 -238,-210 -473,-265zm1363 2781l0 161 0 546c0,-273 -90,-521 -302,-495 -380,46 -779,59 -1123,61l0 37 -279 -1 0 -44c-67,-3 -131,-6 -192,-9l-1 -142 -53 0c-124,33 -162,241 -383,241 -174,0 -549,-45 -600,-173 -35,-342 -74,-896 78,-896 108,0 216,0 324,0 0,-72 0,-144 0,-215 0,-194 51,-306 295,-306 0,127 0,254 0,381 0,254 132,324 375,339l3 603c73,4 150,7 230,10l0 56 259 1 0 -50c428,7 913,-13 1369,-105z"/>
   <path class="bkcfil4" d="M4600 7958c-284,-7 -440,-66 -440,-342 0,-127 0,-254 0,-381 -244,0 -295,112 -295,306 0,72 0,144 0,216 -108,0 -216,0 -324,0 -97,0 -200,151 -109,296 -79,49 -94,188 -2,250 -75,74 -55,203 31,255 -73,84 -16,267 80,267 174,0 348,0 522,0 221,0 260,-208 383,-241l157 0 -3 -626z"/>
   <path class="bkcfil5" d="M4160 7449l0 -14c-28,0 -47,-32 -47,-197l0 -1c-4,0 -9,0 -13,1 0,176 24,211 60,211z"/>
   <path class="bkcfil9" d="M5014 8478c-36,-28 -88,-22 -116,14 -29,35 -23,87 13,115 36,29 87,23 116,-13 28,-35 22,-87 -13,-116zm-229 -1436c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm-891 0c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm891 2030c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm-891 0c46,0 83,37 83,83 0,45 -37,82 -83,82 -45,0 -82,-37 -82,-82 0,-46 37,-83 82,-83zm891 2031c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm-891 0c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm891 2030c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82zm-891 0c46,0 83,37 83,82 0,46 -37,83 -83,83 -45,0 -82,-37 -82,-83 0,-45 37,-82 82,-82z"/>
  </g>
 </g>
 <g id="Beard">
  <path class="bkcfil8" d="M4322 5962c-198,0 -104,-134 -210,-205 -149,-99 -202,-47 -170,-313 -126,8 -130,228 -73,237 -224,-48 -166,-239 -181,-258 -20,12 -106,59 -104,77 -18,-80 -53,-154 -24,-233 -121,90 -239,7 -310,-103 283,0 -59,-281 -201,-191 -12,-74 44,-98 62,-118 -38,-40 -90,-30 -131,-19 58,-60 70,-141 54,-188l114 -82 1138 191 1115 -191 114 82c-16,47 -3,128 55,188 -41,-11 -94,-21 -132,19 18,20 75,44 63,118 -142,-90 -484,191 -202,191 -70,110 -189,193 -309,103 28,79 -6,153 -24,233 1,-18 -84,-65 -105,-77 -15,19 43,210 -181,258 57,-9 54,-229 -72,-237 10,87 -3,210 -73,269 -126,106 -288,83 -213,249z"/>
 </g>
</svg></div>

    <div id="header">
      <a href="http://94660.giftcardrebel.co/94660/index.php" id="logo" title="Gift Card Rebel"><svg id="logo-svg" width="100%" height="100%" viewBox="0 0 13889 3106" preserveAspectRatio="none" style="fill-rule:evenodd; clip-rule:evenodd">
 <defs><style type="text/css"><![CDATA[.logofil0 {fill:#1F2227} .logofil1 {fill:#1F2227;fill-rule:nonzero} ]]></style></defs>
 <g id="Body">
  <g id="_1387141822048">
   <path class="logofil0" d="M1232 3106c-120,0 -63,-81 -127,-125 -90,-60 -122,-28 -103,-190 -76,5 -78,138 -43,144 -136,-29 -101,-146 -110,-157 -12,7 -64,36 -63,47 -11,-49 -32,-94 -14,-142 -73,54 -144,4 -187,-63 170,0 -36,-171 -122,-116 -7,-45 27,-60 38,-72 -55,-59 -109,-3 -85,97 -293,-204 -346,-421 -199,-691 -89,8 -163,-7 -189,-87 95,51 155,39 250,-55 -88,1 -181,3 -278,21 451,-251 196,-576 337,-1093 52,-190 188,-351 353,-464 320,-218 620,-212 832,11 447,-134 548,235 575,599 29,383 -53,707 319,952 -90,4 -179,-2 -267,-20 78,87 139,83 247,53 -49,72 -93,94 -175,95 116,306 54,449 -208,643 9,-96 -78,-93 -108,-61 11,12 45,27 38,72 -86,-55 -292,116 -122,116 -42,67 -114,117 -187,63 18,48 -3,93 -14,142 1,-11 -51,-40 -63,-47 -9,11 26,128 -109,157 34,-6 32,-139 -44,-144 6,53 -1,128 -44,164 -76,64 -174,50 -128,151zm-686 -1793l53 0c16,-132 100,-182 288,-182 102,0 264,7 278,126l70 0c14,-119 176,-126 278,-126 188,0 271,50 288,182l57 0c1,-22 2,-44 3,-66 -101,-258 104,-635 -235,-785 -300,386 -848,214 -1087,706 -1,51 2,99 7,145zm50 35l-46 0c10,86 24,173 25,284 -51,-69 -92,-145 -111,-240 -47,51 -97,88 -150,111 94,285 178,340 254,244 -4,150 46,273 246,314 25,-124 150,-186 396,-174 247,-12 371,50 396,174 193,-40 246,-154 247,-297 87,74 172,-8 255,-261 -64,-22 -113,-59 -143,-115 -34,103 -75,176 -120,231 4,-89 8,-179 12,-271l-53 0c0,6 0,12 0,19 0,163 -78,278 -215,278 -157,0 -342,-187 -355,-353l-68 0c-13,166 -198,353 -356,353 -137,0 -214,-115 -214,-278 0,-7 0,-13 0,-19zm614 843c-45,0 -90,0 -136,0 94,63 117,161 50,145 -167,-41 -252,-104 -227,-207 98,-14 180,-53 237,-131 22,19 46,34 76,34 31,0 55,-15 77,-34 57,78 139,117 237,131 25,103 -60,166 -228,207 -66,16 -43,-82 50,-145 -45,0 -90,0 -136,0z"/>
   <path class="logofil1" d="M3455 611c44,0 85,8 124,25 39,17 72,40 101,68 28,29 51,62 68,101 17,39 25,80 25,124l0 81c0,23 -11,39 -33,45l-229 84c-22,6 -33,-2 -33,-26l0 -171c0,-17 -6,-32 -18,-43 -12,-12 -26,-18 -43,-18l-20 0c-17,0 -31,6 -43,18 -12,11 -18,26 -18,43l0 1141c0,17 6,31 18,43 12,12 26,18 43,18l20 0c17,0 31,-6 43,-18 12,-12 18,-26 18,-43l0 -449 -71 0 0 -288 331 0c24,0 35,12 35,35l0 715c0,44 -8,85 -25,124 -17,38 -40,72 -68,101 -29,28 -62,51 -101,68 -39,17 -80,25 -124,25l-96 0c-44,0 -85,-8 -124,-25 -38,-17 -72,-40 -101,-68 -28,-29 -51,-63 -68,-101 -17,-39 -25,-80 -25,-124l0 -1167c0,-44 8,-85 25,-124 17,-39 40,-72 68,-101 29,-28 63,-51 101,-68 39,-17 80,-25 124,-25l96 0zm763 1750c0,24 -12,35 -35,35l-225 0c-24,0 -35,-11 -35,-35l0 -1697c0,-24 11,-36 35,-36l225 0c23,0 35,12 35,36l0 1697zm758 -1733c24,0 36,12 36,36l0 225c0,23 -12,35 -36,35l-288 0 0 364 250 0c24,0 36,11 36,35l0 225c0,23 -12,35 -36,35l-250 0 0 778c0,24 -11,35 -35,35l-225 0c-23,0 -35,-11 -35,-35l0 -1697c0,-24 12,-36 35,-36l548 0zm809 0c23,0 35,12 35,36l0 225c0,23 -12,35 -35,35l-179 0 0 1437c0,24 -12,35 -36,35l-225 0c-8,0 -16,-3 -24,-10 -7,-6 -11,-15 -11,-25l0 -1437 -177 0c-23,0 -35,-12 -35,-35l0 -225c0,-24 12,-36 35,-36l652 0zm794 -17c43,0 85,8 123,25 39,17 73,40 101,68 29,29 52,62 69,101 16,39 25,80 25,124l0 202c0,24 -11,39 -33,45l-230 36c-22,7 -33,-2 -33,-25l0 -245c0,-17 -6,-32 -17,-43 -12,-12 -26,-18 -43,-18l-20 0c-17,0 -32,6 -43,18 -12,11 -18,26 -18,43l0 1141c0,17 6,31 18,43 11,12 26,18 43,18l20 0c17,0 31,-6 43,-18 11,-12 17,-26 17,-43l0 -353c0,-24 11,-32 33,-26l230 31c22,6 33,22 33,45l0 316c0,44 -9,85 -25,124 -17,38 -40,72 -69,101 -28,28 -62,51 -101,68 -38,17 -80,25 -123,25l-96 0c-44,0 -85,-8 -124,-25 -39,-17 -73,-40 -101,-68 -29,-29 -52,-63 -68,-101 -17,-39 -26,-80 -26,-124l0 -1167c0,-44 9,-85 26,-124 16,-39 39,-72 68,-101 28,-28 62,-51 101,-68 39,-17 80,-25 124,-25l96 0zm1187 1750c3,24 -7,35 -30,35l-230 0c-22,0 -35,-11 -38,-35l-20 -273 -157 0 -20 273c-3,24 -16,35 -38,35l-230 0c-23,0 -33,-11 -30,-35l189 -1697c4,-24 17,-36 41,-36l333 0c24,0 37,12 41,36l189 1697zm-338 -556l-48 -684 -21 0 -48 684 117 0zm1235 556c5,24 -3,35 -25,35l-230 0c-10,0 -20,-3 -29,-10 -9,-6 -16,-15 -19,-25l-184 -619 0 654 -3 -25c-3,17 -14,25 -33,25l-225 0c-23,0 -35,-11 -35,-35l0 -1697c0,-24 12,-36 35,-36l379 0c44,0 85,9 124,26 39,16 73,39 101,68 29,28 51,62 68,101 17,39 26,80 26,124l0 411c0,63 -16,119 -48,168 -32,50 -74,88 -127,115l225 720zm-487 -955l80 0c17,0 32,-6 43,-17 12,-12 18,-26 18,-43l0 -387c0,-17 -6,-31 -18,-43 -11,-11 -26,-17 -43,-17l-80 0 0 507zm1015 -778c44,0 85,9 124,26 39,16 73,39 101,68 29,28 51,62 68,101 17,39 26,80 26,124l0 1131c0,44 -9,85 -26,124 -17,39 -39,72 -68,101 -28,29 -62,51 -101,68 -39,17 -80,25 -124,25l-379 0c-23,0 -35,-11 -35,-35l0 -1697c0,-24 12,-36 35,-36l379 0zm23 331c0,-17 -6,-31 -18,-43 -11,-11 -26,-17 -43,-17l-80 0 0 1227 80 0c17,0 32,-6 43,-17 12,-12 18,-27 18,-43l0 -1107zm1473 1402c5,24 -3,35 -25,35l-230 0c-10,0 -20,-3 -29,-10 -9,-6 -15,-15 -19,-25l-184 -619 0 654 -3 -25c-3,17 -14,25 -33,25l-224 0c-24,0 -36,-11 -36,-35l0 -1697c0,-24 12,-36 36,-36l379 0c43,0 85,9 123,26 39,16 73,39 101,68 29,28 52,62 69,101 16,39 25,80 25,124l0 411c0,63 -16,119 -48,168 -32,50 -74,88 -126,115l224 720zm-487 -955l81 0c17,0 31,-6 43,-17 11,-12 17,-26 17,-43l0 -387c0,-17 -6,-31 -17,-43 -12,-11 -26,-17 -43,-17l-81 0 0 507zm1185 695c23,0 35,12 35,35l0 225c0,24 -12,35 -35,35l-548 0c-24,0 -36,-11 -36,-35l0 -1697c0,-24 12,-36 36,-36l548 0c23,0 35,12 35,36l0 225c0,23 -12,35 -35,35l-288 0 0 364 250 0c23,0 35,11 35,35l0 225c0,23 -12,35 -35,35l-250 0 0 518 288 0zm859 -586c23,24 41,51 53,83 12,32 18,68 18,106l0 374c0,44 -9,85 -26,124 -16,39 -39,72 -68,101 -28,29 -62,51 -101,68 -39,17 -80,25 -124,25l-379 0c-23,0 -35,-11 -35,-35l0 -1697c0,-24 12,-36 35,-36l379 0c44,0 85,9 124,26 39,16 73,39 101,68 29,28 52,62 68,101 17,39 26,80 26,124l0 252c0,78 -24,142 -71,195 -25,27 -56,49 -91,65 37,14 67,32 91,56zm-225 149c0,-17 -6,-31 -18,-43 -11,-12 -26,-18 -43,-18l-80 0 0 523 80 0c17,0 32,-6 43,-17 12,-12 18,-27 18,-43l0 -402zm0 -705c0,-17 -6,-31 -18,-43 -11,-11 -26,-17 -43,-17l-80 0 0 429 80 0c17,0 32,-6 43,-18 12,-11 18,-26 18,-43l0 -308zm1016 1142c23,0 35,12 35,35l0 225c0,24 -12,35 -35,35l-548 0c-24,0 -36,-11 -36,-35l0 -1697c0,-24 12,-36 36,-36l548 0c23,0 35,12 35,36l0 225c0,23 -12,35 -35,35l-288 0 0 364 250 0c24,0 35,11 35,35l0 225c0,23 -11,35 -35,35l-250 0 0 518 288 0zm819 0c23,0 35,12 35,35l0 225c0,24 -12,35 -35,35l-341 0 -6 0 -2 0 -225 0c-23,0 -35,-11 -35,-35l0 -1697c0,-24 12,-36 35,-36l225 0c24,0 35,12 35,36l0 1437 314 0z"/>
  </g>
 </g>
</svg></a>

      <div id="intro">
        <span id="intro1">Psst! Hey there!</span>
        <span id="intro2">Do you want some </span><h1>Free Gift Cards</h1>
        <div id="scrolldown">
          <svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd"
viewBox="0 0 13889 7639">
           <defs><style type="text/css"> <![CDATA[.filscroll0 {fill:#1F2227} ]]> </style></defs>
           <g><polygon class="filscroll0" points="741,0 6944,6166 13148,0 13889,736 7685,6903 7685,6903 6944,7639 6944,7639 6944,7639 6204,6903 6204,6903 0,736 "/></g>
          </svg>
        </div>
      </div>
    </div>

<div id="page">
  <h2>Choose Gift Card</h2>
  <div id="home">
    <a class="home-card card-free-google-play-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=googleplay">
  <div class="home-card-title">Free Google Play Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh2color{fill:#2c8597}]]></style></defs>
 <g>
  <path class="svgh2color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filgoogleplay0 {fill:none} .filgoogleplay1 {fill:#43C3C3} .filgoogleplay3 {fill:#91E1A8} .filgoogleplay4 {fill:#C4397A} .filgoogleplay2 {fill:#FCA078} .filgoogleplay5 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filgoogleplay0" width="16667" height="23611"/>
  <g>
   <g>
    <path class="filgoogleplay1" d="M4313 19408c-190,-107 -298,-291 -298,-506l0 -9520c0,-214 108,-398 298,-506l5623 5266 -5623 5266z"/>
    <path class="filgoogleplay2" d="M13312 14648l-2118 1199 -1317 -426 -360 -1279 181 -1234 1504 -470 2110 1198c189,108 298,292 298,506 0,215 -108,399 -298,506z"/>
    <path class="filgoogleplay3" d="M4313 8876c189,-107 406,-107 596,0l6293 3562 0 0 -1685 1704 -5204 -5266z"/>
    <path class="filgoogleplay4" d="M4313 19408c189,107 406,107 596,0l6293 -3561 0 0 -1685 -1705 -5204 5266z"/>
   </g>
   <path class="filgoogleplay5" d="M7052 6735c-78,-69 -145,-176 -183,-250l265 -114c18,33 42,83 82,126 68,74 159,124 270,124 103,0 219,-47 281,-132 55,-76 76,-173 76,-277l0 -104c-190,244 -605,210 -837,-42 -248,-270 -246,-708 5,-977 248,-246 615,-277 831,-44 0,0 1,0 1,0l0 -117 288 0 0 1251c0,319 -117,499 -262,603 -107,77 -255,112 -387,112 -170,0 -317,-59 -430,-159zm6900 69l0 0 278 -659 -492 -1142 280 0 351 814 343 -814 280 0 -759 1801 -281 0zm-1330 -629l0 0c-80,-76 -123,-196 -124,-306 -1,-96 32,-193 102,-269 113,-120 283,-172 461,-172 116,0 219,23 297,68 0,-201 -157,-278 -290,-278 -124,0 -232,65 -274,178l-252 -102c45,-122 186,-330 519,-330 163,0 324,58 429,169 105,112 140,251 140,436l0 691 -275 0 0 -124c-36,46 -91,91 -150,120 -71,34 -154,46 -230,46 -125,0 -263,-40 -353,-127zm-8785 -595l0 0c0,-329 251,-692 686,-692 435,0 686,363 686,692 0,330 -251,693 -686,693 -435,0 -686,-363 -686,-693zm1489 0l0 0c0,-329 251,-692 686,-692 435,0 686,363 686,692 0,330 -251,693 -686,693 -435,0 -686,-363 -686,-693zm-3347 364l0 0c-415,-418 -402,-1090 13,-1508 209,-210 482,-315 757,-314 262,1 524,99 729,291l-206 215c-297,-289 -770,-286 -1062,14 -294,306 -301,796 -7,1101 297,306 789,323 1086,18 100,-103 134,-235 154,-369l-695 0 0 -295 977 0c14,74 16,150 16,224 0,242 -105,499 -266,665 -185,189 -443,287 -716,285 -283,-3 -567,-114 -780,-327zm6964 124l0 0c-245,-270 -245,-712 0,-982 244,-269 661,-268 898,-1 78,87 130,201 176,318l-914 385c53,108 159,211 325,211 143,0 240,-48 342,-193l239 161 0 0c-27,37 -61,73 -87,101 -244,270 -735,270 -979,0zm1718 193l0 0 0 -1823 586 0c354,0 621,248 621,552 0,305 -254,552 -566,552l-363 0 0 719 -278 0zm1389 0l0 0 0 -1823 278 0 0 1823 -278 0zm-3724 -29l0 0 0 -2041 305 0 0 2041 -305 0zm5030 -505l0 0c-68,-47 -172,-67 -262,-67 -198,0 -309,100 -309,209 0,122 117,183 226,183 159,0 345,-133 345,-325zm-8450 -147l0 0c0,-199 -140,-418 -383,-418 -243,0 -383,220 -383,418 0,199 140,418 383,418 243,0 383,-219 383,-418zm1489 0l0 0c0,-199 -140,-418 -383,-418 -243,0 -383,220 -383,418 0,199 140,418 383,418 243,0 383,-219 383,-418zm1455 126l0 0c3,-9 7,-29 11,-49 0,-4 1,-7 0,-7 4,-24 6,-48 6,-73 0,-24 -2,-47 -6,-69 0,-4 -1,-9 -1,-9 -4,-21 -9,-42 -16,-61 -52,-162 -190,-276 -351,-275 -205,2 -371,190 -369,420 1,230 169,415 374,414 162,-2 298,-119 352,-291zm1206 -150l0 0 610 -259c-63,-109 -165,-143 -252,-143 -233,0 -392,264 -358,402zm2528 -559l0 0c0,-160 -125,-289 -311,-289l-334 0 0 577 350 0c164,0 295,-129 295,-288z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-xbox-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=xbox">
  <div class="home-card-title">Free Xbox Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh4color{fill:#27ae60}]]></style></defs>
 <g>
  <path class="svgh4color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filxbox0 {fill:none} .filxbox1 {fill:white} .filxbox2 {fill:white;fill-rule:nonzero} ]]> </style> </defs>
 <g>
  <rect class="filxbox0" width="16667" height="23611"/>
  <g>
   <path class="filxbox1" d="M7393 13462c-711,689 -3429,3308 -2911,4326 108,213 719,688 982,833 851,473 1636,816 2872,813 1177,-4 2090,-342 2891,-830 283,-172 868,-610 981,-870 181,-421 -225,-1060 -385,-1333l-764 -1077c-483,-584 -2324,-2449 -2723,-2759l-943 897zm-3495 3773c106,-1774 1064,-3430 2064,-4695 122,-154 996,-1085 1042,-1200 -357,-286 -1752,-1615 -2407,-1546 -402,231 -1041,1128 -1313,1665 -667,1312 -743,2925 -217,4331 173,461 550,1180 831,1445zm8868 -21c112,-64 142,-144 222,-262 1108,-1621 1242,-3560 463,-5337 -247,-562 -698,-1199 -1114,-1610 -174,-173 -284,-307 -642,-156 -498,210 -1827,1230 -2041,1539 1080,1034 3045,3507 3112,5826zm-7325 -8133c185,79 885,-198 2293,699 192,122 433,317 602,400 1010,-627 1549,-1155 2929,-1070 -515,-532 -2031,-880 -2892,-887 -600,-6 -1136,83 -1658,243 -308,94 -1102,419 -1274,615z"/>
   <path class="filxbox2" d="M5837 6771l-343 0 -710 -1140 -729 1140 -325 0 873 -1331 -816 -1219 347 0 660 1021 686 -1021 319 0 -821 1214 859 1336zm614 -1214l0 969 533 0c216,0 377,-40 486,-120 108,-79 161,-204 161,-373 0,-176 -58,-299 -174,-370 -117,-70 -299,-106 -546,-106l-460 0zm0 -240l546 0c178,0 313,-30 404,-92 90,-62 136,-173 136,-331 0,-160 -54,-270 -163,-330 -109,-61 -277,-91 -506,-91l-417 0 0 844zm-298 -1096l731 0c327,0 570,50 728,150 158,100 237,259 237,478 0,32 -2,64 -6,95 -4,32 -14,73 -31,122 -17,49 -39,94 -68,135 -29,41 -71,82 -127,123 -56,41 -121,73 -196,97 172,32 302,105 390,217 89,113 133,248 133,407 0,231 -76,410 -227,536 -151,127 -376,190 -675,190l-889 0 0 -2550zm2427 1276c0,328 75,585 226,771 151,187 373,280 667,280 294,0 516,-93 664,-279 149,-186 224,-443 224,-772 0,-335 -75,-596 -225,-781 -150,-185 -370,-278 -661,-278 -291,0 -513,93 -666,278 -153,185 -229,446 -229,781zm2100 0c0,194 -27,372 -81,532 -53,162 -130,299 -230,415 -101,116 -227,205 -380,269 -153,64 -325,95 -516,95 -258,0 -478,-54 -661,-164 -183,-110 -321,-263 -412,-459 -91,-196 -137,-426 -137,-690 0,-408 106,-729 319,-965 212,-236 510,-353 893,-353 377,0 672,118 885,356 213,237 320,558 320,964zm2256 1274l-343 0 -710 -1140 -729 1140 -325 0 873 -1331 -815 -1219 346 0 660 1021 686 -1021 319 0 -821 1214 859 1336z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-steam-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=steam">
  <div class="home-card-title">Free Steam Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh6color{fill:#363C4A}]]></style></defs>
 <g>
  <path class="svgh6color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filsteam0 {fill:none} .filsteam2 {fill:#FEFEFE} .filsteam1 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filsteam0" width="16667" height="23611"/>
  <g>
   <path class="filsteam1" d="M6170 14383c-88,-528 1829,-246 1713,1178 -73,903 -1057,1567 -1990,1026 -615,-356 -368,-685 -125,-580 67,29 185,155 236,197 350,288 913,232 1217,-66 515,-506 289,-1372 -377,-1569 -213,-63 -633,63 -674,-186zm2141 -6543c3112,0 5634,2522 5634,5633 0,3112 -2522,5634 -5634,5634 -2632,0 -4842,-1806 -5461,-4245l640 272c404,176 817,352 1226,520 303,124 130,23 345,518 81,184 262,437 366,517 333,259 695,489 1307,433 719,-67 1266,-592 1435,-1170 38,-130 49,-230 70,-364 29,-198 63,-152 198,-253 465,-349 1046,-818 1483,-1125 418,-294 185,-200 617,-269 924,-148 1617,-785 1831,-1661 122,-500 47,-1038 -160,-1463 -328,-677 -1135,-1362 -2221,-1226 -958,120 -1646,785 -1875,1631 -100,370 72,331 -267,800l-1021 1406c-326,454 -218,326 -494,367 -177,26 -634,216 -658,215 -4,0 -1460,-609 -2951,-1239 346,-2780 2717,-4931 5590,-4931zm1794 2421c1564,-139 2325,1982 852,2831 -951,548 -2121,-152 -2225,-1181 -88,-867 601,-1581 1373,-1650zm1227 1695c127,-658 -369,-1173 -888,-1280 -674,-140 -1197,350 -1292,880 -263,1471 1902,1838 2180,400z"/>
   <path class="filsteam2" d="M11354 6231l367 -4c-1,-358 -11,-748 5,-1087l126 336c43,111 98,229 130,342l283 1c35,-134 157,-403 217,-588 4,-12 10,-31 13,-40 2,-4 7,-16 9,-20 21,-42 4,-10 17,-28 18,212 -21,965 17,1084 401,-2 393,45 392,-99 0,-36 -1,-72 -1,-109 0,-451 16,-1112 -1,-1511l-450 -5c-45,58 -142,327 -175,414 -38,97 -123,334 -174,411l-328 -821 -454 -4c-13,168 -13,1632 7,1728zm-7623 -75c160,53 249,106 452,123 813,68 877,-629 698,-858 -78,-101 -204,-160 -365,-213 -204,-67 -364,-59 -366,-210 -2,-168 215,-185 382,-156 189,32 248,161 378,182l0 -399c-260,-118 -682,-188 -930,-10 -308,220 -288,599 -111,797 81,91 251,142 412,180 524,125 245,485 -179,339 -152,-52 -247,-140 -370,-201l-1 426zm6053 -601c16,-72 133,-495 155,-525l142 526 -297 -1zm-84 318l470 -1 92 354 416 -3 -526 -1720 -426 1 -517 1723 393 -3 98 -351zm-2239 354l1051 -1 -1 -336 -651 -3 0 -417 599 -5 2 -330 -601 -2 1 -289 650 -3 0 -335 -1047 -2 -3 1723zm-2063 -1381l450 -5c34,308 -32,1161 11,1390l390 -4 -1 -1382 462 -4 -4 -333 -1308 -5 0 343z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-microsoft-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=microsoft">
  <div class="home-card-title">Free Microsoft Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh14color{fill:#fff}]]></style></defs>
 <g>
  <path class="svgh14color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filmicrosoft0 {fill:none} .filmicrosoft4 {fill:#02A4EF} .filmicrosoft3 {fill:#80BA01} .filmicrosoft2 {fill:#F25022} .filmicrosoft5 {fill:#FFB902} .filmicrosoft1 {fill:#706d6e} ]]> </style> </defs>
 <g id="Layer_x0020_1">
  <rect class="filmicrosoft0" width="16667" height="23611"/>
  <g id="_2347707709520">
   <path class="filmicrosoft1" d="M12111 4925c128,-83 293,-90 436,-51 2,86 1,171 1,257 -68,-30 -149,-50 -220,-21 -57,23 -91,82 -100,140 -11,74 -4,149 -6,224 146,0 292,0 438,0 1,-94 -1,-189 1,-284 99,-28 197,-60 296,-90 1,125 -1,250 1,375 99,-1 198,0 296,-1l0 243c-99,-4 -198,-1 -297,-1 1,140 0,279 0,419 2,77 -4,155 5,232 6,46 22,96 65,120 71,39 162,22 227,-22l0 245c-85,38 -181,49 -273,42 -88,-6 -179,-38 -236,-108 -66,-79 -83,-185 -85,-285 0,-215 0,-429 0,-643 -146,0 -292,-1 -438,0 0,336 0,672 0,1009 -100,0 -199,0 -299,0 0,-336 -1,-673 0,-1009 -69,-1 -139,0 -208,-1 0,-80 1,-160 0,-240 69,-1 138,-1 207,0 5,-107 -11,-216 21,-319 27,-94 86,-178 168,-231zm-6406 18c61,-9 126,11 166,59 47,51 56,134 21,194 -39,68 -124,100 -199,83 -78,-14 -143,-86 -139,-166 -3,-85 68,-161 151,-170zm-2292 37c145,0 289,0 435,0 135,344 272,687 407,1031 35,86 67,173 103,259 175,-430 351,-859 524,-1289 140,-2 279,-1 419,-1 0,582 0,1163 0,1745 -101,0 -201,1 -302,-1 1,-429 0,-858 1,-1287 0,-20 -1,-39 -2,-58 -6,9 -11,18 -16,28 -173,439 -349,877 -521,1317 -72,2 -143,0 -215,1 -178,-439 -355,-880 -532,-1319 -5,-9 -10,-18 -15,-27 -4,188 -1,377 -2,565 0,260 0,520 0,781 -95,0 -190,0 -284,0 -1,-582 -1,-1163 0,-1745zm3116 493c144,-41 300,-39 444,1 30,9 59,20 86,36 -2,95 0,191 -1,286 -97,-74 -219,-120 -342,-105 -97,9 -190,59 -248,138 -75,98 -92,227 -80,347 10,93 49,186 121,248 76,67 182,91 280,83 98,-11 190,-52 269,-110 1,91 -1,181 0,271 -122,73 -269,92 -409,85 -143,-8 -286,-62 -389,-163 -113,-108 -174,-263 -181,-418 -8,-161 25,-330 118,-464 78,-115 199,-197 332,-235zm2027 -21c144,-19 295,-10 428,50 116,52 210,149 262,264 55,123 68,261 59,395 -9,130 -50,260 -131,364 -84,110 -209,184 -344,212 -115,24 -235,24 -350,-1 -138,-29 -265,-109 -346,-225 -94,-135 -122,-306 -110,-467 9,-137 51,-275 139,-382 95,-120 242,-191 393,-210zm1241 2c138,-24 283,-6 414,43 0,92 0,184 0,275 -91,-63 -203,-96 -314,-93 -56,3 -117,26 -143,80 -20,52 -6,121 44,153 84,56 186,80 274,131 69,39 136,90 171,163 66,137 38,319 -78,421 -110,104 -270,132 -416,127 -104,-7 -209,-28 -304,-70 0,-97 -1,-193 0,-289 80,58 173,100 271,117 69,11 143,11 207,-19 61,-30 72,-117 36,-170 -34,-41 -84,-63 -131,-86 -88,-39 -181,-72 -258,-132 -55,-42 -96,-102 -112,-170 -24,-99 -16,-211 41,-298 66,-101 181,-162 298,-183zm1144 -3c149,-18 308,-8 444,61 119,59 211,166 257,290 36,95 48,198 46,299 1,151 -40,306 -135,426 -89,116 -225,191 -368,215 -140,23 -288,17 -421,-36 -135,-53 -247,-161 -304,-295 -59,-135 -66,-289 -47,-434 19,-145 85,-287 197,-384 92,-81 210,-126 331,-142zm-3213 43c82,-50 187,-54 277,-24 0,100 0,200 0,299 -59,-38 -132,-54 -202,-47 -85,9 -152,75 -187,150 -38,79 -45,168 -43,255 0,199 0,399 0,598 -98,0 -197,0 -295,0 0,-417 1,-833 0,-1250 98,-1 197,-1 295,0 0,71 0,143 0,214 32,-77 80,-153 155,-195zm-2147 -19c99,-1 198,-2 298,0 -2,417 0,833 -1,1250 -99,0 -198,0 -297,0 0,-417 0,-834 0,-1250zm3064 214c90,-6 186,20 250,85 70,68 96,167 104,261 5,103 1,210 -42,305 -29,65 -81,119 -147,145 -78,29 -164,31 -244,10 -81,-21 -150,-80 -188,-154 -48,-96 -55,-208 -45,-313 9,-96 42,-195 115,-261 53,-50 126,-74 197,-78zm2376 0c85,-6 175,14 240,71 60,50 93,124 108,199 17,88 17,179 3,267 -12,66 -34,132 -77,184 -44,52 -108,84 -175,94 -72,11 -147,5 -214,-23 -73,-31 -129,-93 -158,-165 -35,-86 -43,-181 -35,-273 6,-89 31,-180 90,-249 54,-64 136,-100 218,-105z"/>
   <g>
    <path class="filmicrosoft2" d="M3412 8914l4682 0c0,1561 0,3121 0,4682 -1560,0 -3121,0 -4682,0l0 -4682z"/>
    <path class="filmicrosoft3" d="M8572 8914l4682 0c0,1561 1,3121 0,4682 -1560,0 -3121,0 -4681,0 -1,-1561 -1,-3121 -1,-4682z"/>
    <path class="filmicrosoft4" d="M3412 14074c1561,0 3122,0 4682,0 0,1561 0,3121 0,4682l-4682 0 0 -4682z"/>
    <path class="filmicrosoft5" d="M8573 14074c1560,0 3121,0 4681,0 0,1561 0,3121 0,4682l-4682 0c1,-1561 0,-3121 1,-4682z"/>
   </g>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-playstation-store-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=playstation">
  <div class="home-card-title">Free PlayStation Store Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh5color{fill:#004098}]]></style></defs>
 <g>
  <path class="svgh5color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filplaystation0 {fill:none} .filplaystation1 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filplaystation0" width="16667" height="23611"/>
  <g>
   <path class="filplaystation1" d="M11590 5216c96,0 259,-13 345,7l5 -301c-66,-12 -285,-17 -347,0 -17,62 -12,236 -3,294zm-4 1678l354 0 0 -1509 -353 0 -1 1509zm-8287 3l349 -3 -4 -1972c-64,-13 -281,-17 -345,0 -17,50 -21,1882 0,1975zm5607 -3l0 -217c-290,0 -280,10 -280,-390 0,-227 -1,-454 0,-681l373 -1 2 -212c-60,-19 -297,-8 -375,-8l-1 -249 -352 -4c-15,103 -4,1005 -4,1189 0,571 221,573 637,573zm2379 -214c-261,-33 -283,86 -283,-393 0,-226 -1,-452 0,-678l372 -4 4 -218 -376 -2 -1 -253 -352 1c-12,105 -6,1134 -3,1310 3,204 92,352 235,419 89,41 191,32 296,32 79,0 108,23 110,-49 1,-53 0,-112 -2,-165zm-4363 -3l0 217c183,-1 366,0 549,0 197,0 309,-31 412,-138 183,-191 185,-636 21,-857 -230,-312 -657,-8 -712,-380 -11,-81 -8,-177 21,-247 30,-72 63,-109 149,-128 80,-18 444,-14 551,-6l-3 -216c-97,-19 -433,-11 -549,-6 -517,22 -588,535 -469,814 216,505 757,59 776,590 15,455 -284,356 -746,357zm5799 -1286c-463,40 -573,366 -555,841 16,464 243,702 737,659 456,-39 565,-379 544,-849 -7,-170 -57,-400 -180,-508 -119,-106 -332,-162 -546,-143zm363 952c-14,127 -37,230 -115,289 -83,62 -241,62 -325,3 -172,-122 -171,-874 -3,-987 83,-56 249,-59 331,2 139,103 134,486 112,693zm586 550l357 1 0 -1288c116,0 327,-26 407,40 208,169 58,981 119,1251l350 -3c-43,-572 192,-1455 -542,-1505 -188,-12 -502,-14 -688,-1l-3 1505zm-4535 -806c0,285 -47,606 190,751 149,91 343,44 536,59l-3 -215c-191,-31 -367,73 -367,-194 0,-203 -20,-567 44,-740 67,-182 240,-142 474,-142l0 1287 356 0 -3 -1503c-97,-12 -474,-5 -599,-5 -444,0 -628,259 -628,702zm-4514 806l0 -216c-230,0 -335,38 -364,-125 -23,-130 -32,-752 86,-888 38,-44 111,-58 189,-59 74,0 186,-9 239,8l0 1281 358 0 -4 -1503c-124,-23 -717,-8 -833,21 -224,58 -346,234 -382,487 -27,195 -41,635 42,790 131,245 345,210 669,204zm910 730l310 0 886 -2238 -336 2c-46,117 -349,931 -382,968l-328 -969 -371 0 478 1415c27,80 33,65 2,143l-259 679zm-3757 -726l349 -3 -4 -1757c86,-5 399,-8 450,8 198,62 194,560 89,704 -116,161 -225,45 -383,96 -20,61 -9,147 -7,214 188,-32 495,75 676,-168 129,-173 176,-424 115,-679 -53,-221 -193,-389 -440,-397 -126,-4 -766,-14 -845,7 -17,51 -21,1882 0,1975z"/>
   <path class="filplaystation1" d="M2075 16341l0 268c148,207 103,217 305,369 126,94 283,167 454,228 1282,455 2206,444 3528,279l1 -1068c-387,92 -770,301 -1171,410 -350,96 -1062,163 -1247,-123 39,-218 308,-270 534,-352 219,-81 415,-150 624,-226l1259 -442 1 -1196 -3386 1212c-483,215 -613,279 -902,641zm7103 -939l-8 1213c478,-18 1974,-872 3011,-872 519,1 882,245 233,479l-3244 1144 0 1188c313,-72 3958,-1409 4389,-1561 881,-312 1513,-929 551,-1434 -832,-437 -1861,-556 -2847,-556 -528,0 -1656,197 -2085,399zm-2286 -6354l-147 0 0 9005 2044 648c50,-823 7,-3126 7,-4106l0 -3063c0,-386 -51,-669 183,-881 769,-151 616,1001 616,1562 0,741 0,1482 0,2224 842,337 1758,382 2127,-676 278,-794 166,-2099 -254,-2707 -702,-1018 -2105,-1317 -3246,-1653l-1224 -309c-46,-13 1,3 -54,-18l-52 -26z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-itunes-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=itunes">
  <div class="home-card-title">Free iTunes Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh7color{fill:#e70094}]]></style></defs>
 <g>
  <path class="svgh7color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filitunes0 {fill:none} .filitunes1 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filitunes0" width="16667" height="23611"/>
  <g>
   <path class="filitunes1" d="M6227 5039c-2,250 -1,502 -1,752 0,272 -13,440 99,655 37,71 120,152 190,188 181,94 434,82 605,-20 39,-22 81,-56 107,-82 23,-24 60,-84 86,-99l24 228 437 0c5,-122 -10,-270 -11,-397l0 -1225 -510 0c0,253 0,506 0,759 0,119 15,256 -30,345 -38,73 -117,143 -230,145 -275,6 -259,-317 -259,-497 0,-251 0,-502 0,-752l-507 0zm1929 -1c-11,53 7,319 8,396 2,137 2,274 2,411 0,158 -8,705 1,816l503 -2c10,-244 1,-507 1,-753 0,-120 -13,-249 37,-344 38,-74 116,-147 229,-150 266,-7 264,253 264,494 0,175 -8,613 1,755l503 -1c9,-149 1,-575 1,-754 0,-246 10,-461 -101,-647 -164,-274 -529,-325 -790,-178 -115,65 -139,128 -195,178 -22,-39 -12,-176 -31,-220l-433 -1zm2341 626c5,-170 133,-319 297,-325 189,-8 296,137 295,326l-592 -1zm1043 348c54,-180 0,-484 -69,-628 -183,-384 -633,-469 -999,-306 -352,156 -510,595 -440,983 77,426 403,623 816,637 180,6 479,-32 621,-104l-64 -340c-44,6 -89,23 -135,33 -260,56 -746,71 -771,-275l1041 0zm-7096 -1162l597 1 0 1809c100,5 453,-7 508,5l2 -1814 609 -1 0 -425 -1715 0c-8,44 -8,379 -1,425zm8388 591c17,-26 84,-297 93,-344 -73,-52 -294,-92 -410,-94 -154,-4 -301,20 -419,79 -254,130 -370,423 -234,661 145,255 545,287 619,386 44,58 26,139 -22,173 -53,38 -139,43 -214,38 -152,-11 -258,-61 -385,-118 -13,18 -20,63 -27,89 -14,57 -62,236 -64,270 177,123 615,148 845,72 282,-94 436,-325 365,-611 -37,-148 -119,-215 -223,-282 -174,-112 -473,-130 -463,-286 4,-71 60,-106 131,-118 184,-30 316,58 408,85zm-9145 1220l504 -1 -3 -1621 -502 0 1 1622zm194 -2323c-335,63 -253,570 118,497 334,-66 246,-566 -118,-497z"/>
   <path class="filitunes1" d="M8209 10307c769,-15 1479,-459 1882,-1050 357,-523 564,-1122 483,-1785 -248,-56 -821,202 -1005,305 -849,473 -1512,1401 -1418,2410 10,103 -3,84 58,120zm5202 5810c-441,-124 -911,-547 -1121,-824 -640,-842 -757,-2067 -198,-2929 422,-652 485,-571 975,-935 -92,-204 -640,-657 -891,-800 -926,-529 -1699,-505 -2680,-131 -1397,532 -1517,19 -2671,-215 -544,-110 -986,-55 -1454,118 -745,275 -1416,936 -1737,1602 -825,1716 -160,3976 637,5322 399,674 922,1426 1566,1773 451,242 885,226 1360,38 442,-176 739,-357 1304,-357 384,0 651,32 988,170 253,103 482,241 773,298 882,171 1545,-520 2000,-1120 153,-203 276,-397 426,-616 163,-238 685,-1151 723,-1394z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-skype-credit-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=skype">
  <div class="home-card-title">Free Skype Credit Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh12color{fill:#3498db}]]></style></defs>
 <g>
  <path class="svgh12color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filskype0 {fill:none} .filskype1 {fill:white;fill-rule:nonzero} ]]> </style> </defs>
 <g>
  <rect class="filskype0" width="16667" height="23611"/>
  <path class="filskype1" d="M13299 9669c-451,0 -866,142 -1208,383 -154,-143 -359,-230 -585,-230 -168,0 -324,49 -457,132 -313,-560 -912,-938 -1599,-938 -629,0 -1183,315 -1515,795 -277,-284 -664,-461 -1093,-461 -283,0 -547,78 -775,213 -5,-542 -444,-978 -987,-978 -545,0 -987,442 -987,987l2 38c-106,-16 -214,-25 -324,-25 -322,0 -626,71 -899,197 -154,-82 -329,-129 -516,-129 -599,0 -1088,487 -1088,1088 0,318 139,603 356,802 -6,65 -9,132 -9,198 0,1190 965,2154 2156,2154 462,0 891,-146 1242,-393 316,432 826,714 1402,714 14,0 28,-1 41,-2 167,471 614,809 1141,809 534,0 987,-347 1147,-827 183,348 547,584 966,584 525,0 962,-370 1068,-863 75,10 153,17 231,17 428,0 816,-162 1111,-427 336,229 742,363 1179,363 1160,0 2099,-941 2099,-2101 0,-1173 -956,-2100 -2099,-2100zm1486 1865c0,262 -79,329 -336,329l-1731 0c0,404 262,699 707,699 578,0 578,-378 887,-378 184,0 315,158 315,299 0,462 -740,677 -1202,677 -870,0 -1300,-480 -1429,-1017 -116,563 -485,1017 -1141,1017 -352,0 -613,-142 -755,-388l-12 0 0 1022c0,252 -152,384 -382,384 -231,0 -383,-132 -383,-384l0 -2853 -860 2439c-184,525 -394,798 -877,798 -341,0 -483,-168 -483,-352 0,-205 148,-310 353,-310l78 0c99,0 210,-4 267,-240l-796 -2272c-29,-82 -50,-144 -66,-196 -18,24 -38,45 -62,70l-566 593 798 1070c26,36 79,120 79,246 0,195 -158,373 -362,373 -189,0 -290,-95 -347,-178l-723 -1024 -268 236 0 583c0,251 -152,383 -383,383 -232,0 -384,-132 -384,-383l0 -282c-137,452 -649,665 -1143,665 -692,0 -1269,-310 -1269,-688 0,-167 95,-319 310,-319 330,0 362,472 928,472 272,0 445,-121 445,-278 0,-194 -167,-226 -439,-294l-452 -110c-445,-110 -792,-294 -792,-809 0,-623 619,-855 1149,-855 582,0 1170,232 1170,583 0,179 -122,335 -321,335 -299,0 -309,-351 -792,-351 -268,0 -441,73 -441,237 0,177 173,220 410,272l319 74c368,83 795,229 918,593l0 -2393c0,-251 152,-382 384,-382 231,0 383,131 383,382l0 1742 849 -944c79,-85 179,-148 294,-148 125,0 257,81 322,198 62,-119 185,-198 329,-198 205,0 347,116 393,289l494 1789 10 0 467 -1736c53,-194 158,-342 368,-342 181,0 286,90 341,183 46,-119 148,-183 314,-183 226,0 346,127 346,363l0 120 12 0c126,-325 435,-483 806,-483 547,0 1035,343 1167,1060 149,-648 647,-1060 1400,-1060 881,0 1385,625 1385,1255zm-4124 1028l0 0c-467,0 -614,-456 -614,-850 0,-436 167,-840 614,-834 409,6 608,382 608,834 0,356 -121,845 -608,850zm2057 -1138l0 0c83,-373 314,-609 697,-609 341,0 603,257 645,609l-1342 0z"/>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-windows-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=windows">
  <div class="home-card-title">Free Windows Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh16color{fill:#0076d6}]]></style></defs>
 <g>
  <path class="svgh16color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filwindows0 {fill:none} .filwindows1 {fill:white} .filwindows2 {fill:white;fill-rule:nonzero} ]]> </style> </defs>
 <g>
  <rect class="filwindows0" width="16667" height="23611"/>
  <g>
   <path class="filwindows1" d="M13251 8941l-5451 704 0 4096 5451 0 0 -4800zm-5666 732l-4170 538 0 3530 4170 0 0 -4068zm-4170 4283l0 3530 4170 538 0 -4068 -4170 0zm4385 4096l5451 704 0 -4800 -5451 0 0 4096z"/>
   <path class="filwindows2" d="M5820 4953l-488 1784 -335 0 -340 -1248c-14,-53 -22,-111 -26,-174l-5 0c-4,59 -14,116 -29,172l-341 1250 -343 0 -498 -1784 324 0 324 1306c13,55 22,112 25,171l6 0c3,-42 15,-99 35,-171l365 -1306 305 0 339 1316c11,45 20,98 26,159l5 0c2,-41 12,-96 28,-164l318 -1311 305 0zm237 242c-47,0 -87,-15 -121,-46 -34,-31 -50,-69 -50,-117 0,-47 16,-86 50,-118 34,-31 74,-47 121,-47 49,0 91,16 125,47 34,32 50,71 50,118 0,45 -16,83 -50,115 -34,32 -76,48 -125,48zm143 1542l-288 0 0 -1274 288 0 0 1274zm1387 0l-288 0 0 -718c0,-238 -84,-357 -253,-357 -87,0 -160,33 -217,99 -58,66 -86,149 -86,249l0 727 -290 0 0 -1274 290 0 0 211 5 0c95,-161 233,-241 413,-241 138,0 244,45 317,135 73,90 109,220 109,390l0 779zm1387 0l-289 0 0 -217 -5 0c-93,164 -236,246 -429,246 -157,0 -282,-57 -376,-171 -95,-114 -142,-269 -142,-466 0,-210 53,-379 157,-506 104,-127 242,-190 416,-190 171,0 296,69 374,206l5 0 0 -788 289 0 0 1886zm-285 -583l0 -166c0,-91 -30,-167 -89,-231 -59,-62 -133,-94 -225,-94 -108,0 -192,40 -254,121 -62,80 -93,192 -93,334 0,130 30,232 89,307 59,75 139,112 240,112 98,0 178,-36 240,-108 61,-73 92,-164 92,-275zm1102 612c-196,0 -353,-59 -471,-178 -117,-119 -176,-277 -176,-473 0,-214 61,-381 184,-502 122,-120 287,-180 494,-180 199,0 354,58 465,175 111,117 167,279 167,487 0,203 -60,366 -180,488 -120,122 -281,183 -483,183zm14 -1103c-113,0 -202,39 -268,118 -65,79 -98,187 -98,326 0,134 33,239 100,315 66,77 155,115 266,115 113,0 201,-37 261,-113 62,-75 92,-183 92,-322 0,-140 -30,-248 -92,-325 -60,-76 -148,-114 -261,-114zm2532 -200l-376 1274 -302 0 -232 -864c-9,-33 -15,-70 -17,-112l-5 0c-2,28 -9,65 -23,110l-251 866 -296 0 -374 -1274 298 0 232 918c7,27 12,63 15,109l8 0c3,-35 9,-72 20,-112l258 -915 271 0 228 922c8,28 14,65 17,109l9 0c1,-31 8,-67 18,-109l227 -922 275 0zm10 1234l0 -268c108,83 227,123 357,123 174,0 261,-51 261,-154 0,-29 -8,-53 -23,-74 -14,-20 -34,-38 -60,-54 -25,-16 -55,-30 -89,-42 -35,-13 -73,-27 -115,-43 -53,-20 -100,-42 -141,-65 -42,-24 -77,-50 -105,-79 -28,-30 -49,-63 -63,-101 -14,-37 -21,-80 -21,-130 0,-61 14,-116 43,-163 30,-46 69,-86 118,-118 48,-31 104,-56 166,-72 62,-16 127,-24 193,-24 118,0 223,18 316,54l0 252c-90,-61 -193,-92 -309,-92 -36,0 -69,3 -99,11 -29,7 -54,18 -75,31 -20,13 -37,29 -48,48 -12,19 -17,39 -17,62 0,27 5,50 17,69 11,19 28,36 51,51 23,14 50,27 83,39 32,13 68,26 110,40 54,22 103,45 147,68 44,23 81,50 111,79 31,29 55,63 71,102 17,39 25,84 25,138 0,64 -15,121 -45,169 -30,48 -69,87 -119,119 -50,32 -107,55 -173,70 -64,16 -133,23 -205,23 -140,0 -260,-23 -362,-69z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-ebay-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=ebay">
  <div class="home-card-title">Free eBay Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh9color{fill:#fff}]]></style></defs>
 <g>
  <path class="svgh9color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filebay0 {fill:none} .filebay1 {fill:#0063D1} .filebay4 {fill:#85B716} .filebay3 {fill:#E43137} .filebay2 {fill:#F4AE01} ]]> </style> </defs>
 <g>
  <rect class="filebay0" width="16667" height="23611"/>
  <g>
   <path class="filebay1" d="M6515 10723c648,-76 1177,344 1236,1030 61,697 -345,1239 -951,1315 -168,21 -358,3 -508,-46 -208,-69 -370,-187 -499,-360 -329,-442 -310,-1088 -11,-1526 165,-240 432,-377 733,-413zm-1681 895l1 460c3,460 -1,914 -16,1373 92,0 663,8 705,-5l22 -419c18,16 22,25 36,43 152,188 420,335 655,408 306,94 682,111 1006,42 504,-107 898,-420 1108,-886 15,-33 66,-187 77,-201 8,-95 29,-151 50,-235 19,-237 36,-397 -5,-639 -59,-352 -225,-672 -468,-899 -134,-125 -233,-188 -403,-272 -463,-230 -1195,-210 -1685,52 -116,61 -249,167 -327,265 -13,17 -22,34 -36,46 -13,-121 -2,-313 -2,-442 0,-163 -9,-1258 5,-1319l-722 0 -1 2628z"/>
   <path class="filebay2" d="M11065 11964c0,264 0,437 -120,645 -215,370 -596,493 -1025,492 -257,-1 -421,-56 -579,-177 -118,-92 -227,-341 -147,-560 62,-170 233,-265 438,-315 419,-101 985,-85 1433,-85zm-2587 234c-21,84 -42,140 -50,235 -46,693 445,1054 1081,1125 322,36 698,0 979,-103 285,-105 461,-228 639,-453l20 449 661 -1c-39,-626 -26,-1256 -26,-1887 0,-244 -10,-348 -67,-570l-5 -8 -10 -28c-11,-17 -15,-39 -25,-58 -9,-21 -20,-39 -31,-60 -20,-35 -52,-85 -65,-115l-4 -7 -5 -9 -8 -4 -9 -12c-13,-9 -1,10 -14,-14 -40,-67 -78,-88 -133,-136 -372,-325 -1074,-353 -1541,-302 -419,46 -851,190 -1075,530 -70,105 -129,241 -135,399l730 0c21,-10 9,6 19,-30 49,-177 150,-290 332,-367 380,-162 1144,-113 1301,386 34,110 28,224 28,344 -276,0 -552,0 -828,0 -425,0 -1015,39 -1375,263 -101,62 -158,106 -226,183 -102,114 -92,122 -158,250z"/>
   <path class="filebay3" d="M4091 11604l-2050 0c5,-863 1155,-1166 1753,-677 152,125 302,368 297,677zm744 474l-1 -460c-26,-123 -7,-149 -60,-332 -110,-383 -373,-700 -718,-868 -321,-156 -632,-203 -1003,-197 -1009,16 -1650,480 -1744,1436 -45,467 20,915 280,1285 194,275 549,490 1024,569 662,110 1488,43 1924,-478 103,-123 202,-317 220,-480l-736 0c-50,190 -255,368 -438,447 -420,183 -1019,99 -1325,-269 -36,-42 -62,-74 -93,-125 -86,-144 -151,-356 -139,-528l2809 0z"/>
   <path class="filebay4" d="M11539 10678c13,24 1,5 14,14 14,-12 -3,-19 10,1 14,21 2,5 -1,11l8 4 5 9 4 7c13,30 45,80 65,115 11,21 22,39 31,60 10,19 14,41 25,58 16,17 17,12 10,28l5 8c10,-5 -4,-23 19,16l225 424c39,77 82,155 122,230 41,75 81,150 120,225 164,303 320,605 486,908l242 456c79,161 116,156 74,231 -43,75 -78,151 -119,226 -125,228 -239,460 -361,682 -37,67 -89,159 -118,228l795 0 2171 -4271 -758 0c-24,77 -106,220 -147,303l-899 1805c-41,84 -101,224 -149,293 -199,-403 -401,-798 -602,-1201l-525 -1053c-18,-37 -50,-127 -82,-147l-826 2 173 325c-11,6 2,11 -17,3z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-paypal-cash-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=paypal">
  <div class="home-card-title">Free PayPal Cash Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh11color{fill:#fff}]]></style></defs>
 <g>
  <path class="svgh11color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filpaypal0 {fill:none} .filpaypal2 {fill:#00247D} .filpaypal3 {fill:#003896} .filpaypal1 {fill:#0A94D6} ]]> </style> </defs>
 <g>
  <rect class="filpaypal0" width="16667" height="23611"/>
  <g>
   <g>
    <path class="filpaypal1" d="M6135 17866l-142 900c-24,152 93,289 247,289l1733 0c205,0 380,-149 412,-351l17 -89 326 -2070 21 -114c32,-203 207,-352 412,-352l259 0c1679,0 2994,-682 3378,-2655 161,-825 78,-1513 -347,-1996 -128,-147 -288,-268 -474,-366l-1151 407 -3643 1926 -1635 510 587 3961z"/>
    <path class="filpaypal2" d="M6635 14694l16 -103 -16 103c37,-232 235,-402 469,-402l977 0c1920,0 3423,-780 3862,-3035 13,-67 24,-132 34,-195l-746 -1096 -4316 -49 -1020 4410 740 367z"/>
    <path class="filpaypal3" d="M7206 11073c22,-140 111,-254 232,-311 55,-27 116,-41 180,-41l2611 0c309,0 597,20 861,63 75,12 149,26 220,41 71,16 140,34 207,53 34,10 66,20 99,31 129,43 250,94 361,153 131,-834 -1,-1401 -452,-1915 -496,-566 -1393,-808 -2541,-808l-3330 0c-235,0 -435,171 -471,402l-1387 8795c-27,173 107,330 282,330l2057 0 516 -3275 555 -3518z"/>
   </g>
   <g>
    <path class="filpaypal1" d="M10368 5359c-47,309 -283,309 -512,309l-130 0 92 -577c5,-35 35,-61 70,-61l60 0c155,0 302,0 378,89 45,53 59,132 42,240zm-100 -806l-861 0c-59,0 -109,42 -118,101l-348 2208c-7,43 27,83 71,83l442 0c41,0 76,-30 82,-71l99 -626c9,-58 59,-101 118,-101l273 0c567,0 894,-274 980,-819 38,-238 2,-425 -110,-555 -122,-144 -339,-220 -628,-220zm2000 1599c-40,235 -227,394 -466,394 -119,0 -215,-39 -277,-112 -61,-72 -84,-175 -64,-289 37,-234 227,-397 462,-397 117,0 212,39 275,112 63,74 88,178 70,292zm574 -803l-412 0c-35,0 -65,26 -71,61l-18 115 -29 -42c-89,-129 -288,-173 -487,-173 -455,0 -845,346 -920,830 -40,241 16,472 153,633 126,148 306,210 519,210 368,0 571,-236 571,-236l-18 115c-7,43 27,83 71,83l371 0c59,0 109,-43 118,-101l223 -1412c7,-43 -26,-83 -71,-83zm486 -736l-353 2249c-7,43 27,83 71,83l355 0c59,0 109,-43 119,-101l348 -2208c1,-4 1,-7 1,-11l0 -2c-1,-38 -32,-70 -72,-70l-398 0c-35,0 -65,25 -71,60z"/>
    <path class="filpaypal3" d="M4226 5359c-47,309 -284,309 -512,309l-130 0 91 -577c6,-35 36,-61 71,-61l60 0c155,0 302,0 378,89 45,53 59,132 42,240zm-100 -806l-861 0c-59,0 -109,42 -118,101l-348 2208c-7,43 26,83 71,83l411 0c59,0 109,-43 118,-101l94 -596c9,-58 59,-101 118,-101l273 0c567,0 894,-274 980,-819 38,-238 1,-425 -110,-555 -123,-144 -340,-220 -628,-220zm1999 1599c-39,235 -226,394 -465,394 -120,0 -215,-39 -277,-112 -61,-72 -84,-175 -64,-289 37,-234 227,-397 462,-397 117,0 212,39 275,112 63,74 88,178 69,292zm575 -803l-412 0c-36,0 -66,26 -71,61l-18 115 -29 -42c-89,-129 -288,-173 -487,-173 -456,0 -845,346 -921,830 -39,241 17,472 154,633 126,148 305,210 519,210 367,0 571,-236 571,-236l-18 115c-7,43 26,83 71,83l371 0c59,0 109,-43 118,-101l223 -1412c7,-43 -27,-83 -71,-83zm2196 0l-414 0c-40,0 -77,20 -99,53l-572 842 -242 -809c-15,-51 -62,-86 -115,-86l-407 0c-49,0 -84,49 -68,95l456 1340 -429 606c-34,47 0,113 59,113l414 0c39,0 76,-19 98,-52l1378 -1989c33,-48 -1,-113 -59,-113z"/>
   </g>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-amazon-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=amazon">
  <div class="home-card-title">Free Amazon Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh8color{fill:#fe9900}]]></style></defs>
 <g>
  <path class="svgh8color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filamazon0 {fill:none} .filamazon1 {fill:#1E1F1F} .filamazon2 {fill:white} .filamazon3 {fill:#1E1F1F;fill-rule:nonzero} ]]> </style> </defs>
 <g>
  <rect class="filamazon0" width="16667" height="23611"/>
  <g>
   <g>
    <path class="filamazon1" d="M9173 12440c82,862 -70,2113 -976,2332 -1052,255 -1354,-1178 -729,-1843 354,-376 1037,-487 1705,-489zm294 2753c52,78 91,157 160,257 59,84 117,148 175,223 556,723 727,398 971,191l434 -364c505,-487 664,-319 226,-945 -301,-431 -340,-655 -339,-1294 0,-550 0,-1101 0,-1652 0,-1345 136,-2678 -1734,-3125 -1224,-292 -2922,-14 -3607,1050 -114,177 -536,968 -285,1160 77,59 1283,211 1445,195 239,-23 226,-304 321,-501 278,-574 1148,-746 1637,-362 337,265 354,933 298,1321 -1431,139 -3069,210 -3751,1554 -575,1133 -295,3056 1506,3260 1669,188 2272,-836 2543,-968z"/>
    <path class="filamazon2" d="M11724 17128c-2446,1132 -5040,959 -7357,-377l-706 -466c-108,-60 -235,-31 -153,137 103,211 775,769 1000,958 1841,1555 4579,1826 6698,626 209,-118 1029,-633 1114,-826 43,-98 21,-211 -71,-253 -99,-44 -414,149 -525,201zm678 843c313,94 712,-842 765,-1242 59,-447 -20,-515 -441,-547 -444,-35 -881,23 -1255,238 -117,67 -266,224 20,195 313,-32 651,-87 977,-43 624,83 -87,1097 -66,1399z"/>
   </g>
   <path class="filamazon3" d="M4282 6448c0,15 -6,27 -17,37 -11,9 -29,15 -53,19 -24,4 -59,6 -106,6 -51,0 -87,-2 -110,-6 -23,-4 -39,-10 -49,-19 -9,-10 -14,-22 -14,-37l0 -119c-61,66 -131,117 -210,153 -78,37 -165,55 -261,55 -79,0 -152,-10 -218,-31 -67,-20 -124,-51 -172,-92 -49,-41 -86,-91 -113,-151 -27,-60 -40,-131 -40,-211 0,-87 17,-162 51,-226 34,-65 85,-117 152,-160 67,-41 151,-72 251,-92 100,-20 217,-30 349,-30l146 0 0 -90c0,-47 -5,-88 -15,-124 -9,-35 -25,-64 -46,-88 -22,-23 -51,-40 -87,-52 -36,-10 -81,-16 -134,-16 -71,0 -133,8 -188,23 -56,16 -104,33 -146,52 -43,19 -78,37 -107,52 -28,16 -51,24 -69,24 -12,0 -23,-5 -32,-12 -10,-8 -18,-19 -24,-34 -6,-14 -10,-32 -14,-53 -3,-21 -5,-45 -5,-70 0,-35 3,-62 9,-82 5,-20 16,-38 31,-54 16,-16 43,-34 82,-53 39,-20 85,-38 137,-54 53,-18 110,-31 171,-42 63,-10 127,-16 192,-16 117,0 217,12 301,35 82,23 151,58 204,105 54,48 93,109 117,183 25,75 37,164 37,266l0 1004zm-414 -640l-161 0c-68,0 -125,5 -173,14 -48,11 -87,25 -117,46 -31,20 -52,44 -66,72 -14,29 -21,62 -21,98 0,63 20,112 59,147 40,36 94,54 165,54 58,0 113,-15 162,-45 50,-30 100,-74 152,-133l0 -253zm3208 635c0,11 -4,20 -11,29 -6,8 -17,15 -33,21 -16,5 -37,10 -64,13 -27,2 -61,4 -102,4 -43,0 -78,-2 -104,-4 -27,-3 -49,-8 -65,-13 -16,-6 -27,-13 -34,-21 -6,-9 -9,-18 -9,-29l0 -885c0,-50 -4,-96 -14,-137 -9,-42 -24,-77 -43,-106 -20,-30 -44,-53 -73,-69 -30,-16 -65,-24 -106,-24 -50,0 -101,19 -152,59 -51,39 -107,95 -166,170l0 992c0,11 -4,20 -11,29 -6,8 -18,15 -34,21 -16,5 -38,10 -65,13 -26,2 -60,4 -100,4 -42,0 -76,-2 -103,-4 -27,-3 -48,-8 -64,-13 -17,-6 -28,-13 -35,-21 -6,-9 -10,-18 -10,-29l0 -885c0,-50 -4,-96 -14,-137 -9,-42 -23,-77 -43,-106 -19,-30 -43,-53 -73,-69 -30,-16 -66,-24 -105,-24 -52,0 -103,19 -154,59 -52,39 -107,95 -166,170l0 992c0,11 -3,20 -10,29 -6,8 -18,15 -34,21 -16,5 -38,10 -64,13 -27,2 -61,4 -102,4 -41,0 -76,-2 -102,-4 -27,-3 -48,-8 -64,-13 -17,-6 -28,-13 -35,-21 -6,-9 -10,-18 -10,-29l0 -1493c0,-11 3,-21 9,-30 5,-8 15,-15 29,-21 15,-5 33,-9 56,-12 23,-3 52,-4 87,-4 35,0 65,1 88,4 23,3 42,7 55,12 12,6 22,13 27,21 6,9 9,19 9,30l0 172c82,-89 165,-155 246,-200 83,-44 168,-67 257,-67 62,0 117,7 166,20 49,12 93,31 132,55 38,24 71,52 99,85 28,34 51,71 70,112 45,-48 89,-89 131,-123 44,-35 86,-63 128,-85 41,-21 83,-37 125,-48 42,-10 85,-16 128,-16 99,0 183,17 251,51 68,33 122,78 164,136 42,57 72,124 90,202 17,76 27,158 27,244l0 955zm1683 5c0,15 -6,27 -17,37 -11,9 -29,15 -53,19 -24,4 -59,6 -107,6 -50,0 -86,-2 -109,-6 -23,-4 -40,-10 -49,-19 -9,-10 -14,-22 -14,-37l0 -119c-62,66 -131,117 -210,153 -78,37 -166,55 -261,55 -79,0 -152,-10 -218,-31 -67,-20 -124,-51 -172,-92 -49,-41 -86,-91 -113,-151 -27,-60 -40,-131 -40,-211 0,-87 17,-162 50,-226 35,-65 86,-117 153,-160 67,-41 151,-72 251,-92 100,-20 216,-30 349,-30l145 0 0 -90c0,-47 -4,-88 -14,-124 -9,-35 -25,-64 -47,-88 -21,-23 -50,-40 -86,-52 -36,-10 -81,-16 -135,-16 -70,0 -133,8 -187,23 -56,16 -104,33 -147,52 -42,19 -77,37 -106,52 -28,16 -51,24 -69,24 -12,0 -23,-5 -32,-12 -10,-8 -18,-19 -24,-34 -6,-14 -11,-32 -14,-53 -3,-21 -5,-45 -5,-70 0,-35 3,-62 8,-82 6,-20 16,-38 32,-54 16,-16 43,-34 82,-53 39,-20 84,-38 137,-54 53,-18 110,-31 171,-42 63,-10 126,-16 192,-16 117,0 217,12 300,35 83,23 152,58 205,105 53,48 93,109 117,183 25,75 37,164 37,266l0 1004zm-415 -640l-160 0c-68,0 -126,5 -174,14 -47,11 -86,25 -117,46 -30,20 -52,44 -65,72 -14,29 -21,62 -21,98 0,63 20,112 59,147 39,36 94,54 164,54 59,0 113,-15 163,-45 50,-30 100,-74 151,-133l0 -253zm1879 518c0,33 -1,60 -5,84 -3,23 -8,41 -13,54 -5,14 -13,23 -21,28 -10,5 -20,7 -31,7l-976 0c-30,0 -53,-10 -69,-30 -17,-20 -25,-53 -25,-99l0 -77c0,-20 1,-39 2,-55 2,-16 5,-32 11,-46 5,-16 12,-31 20,-47 8,-16 19,-33 33,-52l561 -861 -532 0c-21,0 -38,-14 -52,-40 -13,-27 -19,-70 -19,-129 0,-33 1,-60 4,-82 3,-22 8,-39 13,-52 5,-13 13,-22 22,-27 8,-6 19,-9 31,-9l915 0c16,0 29,2 40,5 11,4 21,9 28,18 7,10 13,22 17,38 4,15 5,34 5,58l0 83c0,22 -1,42 -3,59 -2,17 -6,34 -10,50 -4,15 -11,31 -19,46 -9,16 -18,33 -30,51l-557 859 590 0c10,0 20,3 29,7 8,5 16,13 22,25 6,12 11,29 14,52 4,21 5,49 5,82zm1766 -645c0,127 -17,243 -51,348 -33,104 -84,195 -152,270 -68,76 -153,135 -256,176 -103,41 -222,62 -360,62 -132,0 -248,-18 -346,-55 -98,-37 -180,-91 -244,-161 -65,-70 -113,-156 -144,-259 -31,-102 -47,-219 -47,-351 0,-127 17,-243 51,-348 34,-106 85,-196 153,-271 68,-75 153,-133 256,-175 101,-41 221,-62 358,-62 134,0 250,19 348,55 98,36 179,89 243,159 65,71 112,157 144,260 31,102 47,219 47,352zm-432 17c0,-74 -6,-142 -18,-203 -12,-62 -31,-116 -60,-162 -28,-45 -65,-82 -111,-107 -47,-26 -105,-38 -176,-38 -63,0 -117,11 -165,34 -46,23 -85,56 -116,100 -30,44 -53,97 -67,159 -16,62 -23,132 -23,212 0,73 6,141 18,203 12,62 32,116 60,162 27,45 64,81 112,106 46,25 105,37 174,37 64,0 120,-11 167,-34 47,-23 86,-56 116,-99 30,-44 52,-97 67,-158 15,-63 22,-133 22,-212zm2191 745c0,11 -4,20 -11,29 -6,8 -17,15 -33,21 -16,5 -37,10 -65,13 -27,2 -61,4 -101,4 -41,0 -76,-2 -103,-4 -27,-3 -49,-8 -65,-13 -16,-6 -27,-13 -33,-21 -7,-9 -11,-18 -11,-29l0 -851c0,-73 -5,-130 -16,-171 -10,-42 -25,-77 -45,-106 -20,-30 -46,-53 -78,-69 -32,-16 -68,-24 -111,-24 -53,0 -107,19 -162,59 -54,39 -111,95 -170,170l0 992c0,11 -3,20 -10,29 -6,8 -18,15 -34,21 -16,5 -38,10 -64,13 -27,2 -61,4 -102,4 -42,0 -76,-2 -103,-4 -26,-3 -48,-8 -63,-13 -17,-6 -29,-13 -35,-21 -7,-9 -10,-18 -10,-29l0 -1493c0,-11 3,-21 9,-30 5,-8 15,-15 29,-21 15,-5 33,-9 56,-12 23,-3 52,-4 86,-4 36,0 65,1 89,4 23,3 41,7 55,12 12,6 21,13 27,21 6,9 9,19 9,30l0 172c82,-89 166,-155 251,-200 85,-44 174,-67 267,-67 102,0 187,17 257,51 69,33 125,78 169,136 42,57 73,124 92,202 19,76 29,169 29,277l0 922z"/>
  </g>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-facebook-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=facebook">
  <div class="home-card-title">Free Facebook Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh10color{fill:#4c66a4}]]></style></defs>
 <g>
  <path class="svgh10color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filfacebook0 {fill:none} .filfacebook1 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filfacebook0" width="16667" height="23611"/>
  <path class="filfacebook1" d="M7826 10437c-37,115 -4,2382 -15,2732 722,72 1712,270 1740,-681 10,-347 54,-887 -153,-1106 -269,-285 -623,-175 -1006,-79l-3 -936 -563 70zm4411 789c-668,123 -652,559 -636,1262 16,676 622,814 1143,722 647,-114 634,-587 619,-1265 -12,-594 -516,-832 -1126,-719zm-1890 -5c-680,117 -661,539 -651,1247 14,983 1403,952 1688,364 106,-218 80,-599 76,-866 -10,-672 -578,-837 -1113,-745zm-2794 1889l-78 -434c-170,27 -754,163 -895,1 -5,-5 -133,-228 -5,-256 21,-5 32,-5 53,-6 41,-2 98,2 142,2l806 -1c1,-575 32,-1039 -480,-1176 -221,-59 -526,-47 -723,29 -502,195 -436,694 -424,1219 20,882 980,813 1604,622zm-4799 -1816l71 435c625,-50 922,-193 875,358 -605,4 -1066,-76 -995,660 80,820 981,350 1072,331l23 109 481 0c-53,-1569 392,-2238 -1527,-1893zm-1176 -21l-290 2 -10 470 301 0 0 1443 577 -1 -1 -1442 423 0 38 -468 -460 -3c-12,-522 10,-412 445,-410l81 -450c-322,-43 -621,-111 -880,52 -269,170 -210,440 -224,807zm4252 1901l-67 -482c-161,15 -399,78 -564,21 -179,-61 -158,-265 -158,-486 0,-218 -32,-428 145,-501 158,-65 413,3 577,15 15,-112 77,-397 53,-483 -339,-63 -749,-98 -1039,60 -303,165 -311,478 -311,909 0,424 14,724 313,888 320,175 690,110 1051,59zm7777 -2734l-1 2748 576 -1 -1 -2822 -574 75zm1163 2745l619 3c-43,-150 -509,-906 -514,-966 -7,-73 437,-825 496,-976l-627 -1c-56,183 -487,871 -476,978 8,76 431,799 502,962zm-4281 -1481c-279,67 -216,323 -217,623 0,287 82,485 410,404 256,-64 202,-345 202,-625 1,-281 -77,-479 -395,-402zm1906 1c-281,59 -218,328 -218,622 -1,285 82,482 409,404 256,-62 202,-352 202,-625 1,-294 -69,-468 -393,-401zm-4001 104c-7,82 -22,782 10,890 1,4 4,11 6,16 133,31 377,20 473,-59 121,-100 92,-302 92,-489 0,-487 -23,-554 -581,-358zm-1870 177l502 0c1,-202 -26,-325 -236,-326 -231,-1 -265,110 -266,326zm-2823 726l3 -224c-193,-4 -463,-55 -449,159 15,219 328,110 446,65z"/>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-netflix-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=netflix">
  <div class="home-card-title">Free Netflix Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh13color{fill:#ea2824}]]></style></defs>
 <g>
  <path class="svgh13color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filnetflix0 {fill:none} .filnetflix1 {fill:white} ]]> </style> </defs>
 <g>
  <rect class="filnetflix0" width="16667" height="23611"/>
  <path class="filnetflix1" d="M3206 9908c-194,0 -401,0 -595,0 -1,809 -2,1333 -4,2141 -255,-789 -511,-1312 -767,-2141 -218,0 -354,0 -572,0 0,1264 0,2528 0,3792 193,-28 400,-54 593,-79 0,-793 1,-1280 1,-2073 266,781 429,1241 694,1982 208,-24 436,-53 644,-74 2,-1183 4,-2365 6,-3548zm2222 0c-552,0 -1097,0 -1648,0 -2,1166 -5,2332 -7,3498 551,-50 1103,-91 1655,-123 1,-170 1,-415 1,-586 -359,22 -702,45 -1060,69 0,-313 1,-573 2,-886 261,-5 537,-1 805,-5 0,-172 0,-418 1,-589 -265,5 -545,5 -805,10 0,-313 1,-485 2,-799 163,-2 324,-2 484,-2 29,0 57,0 85,0 28,0 56,0 84,0 134,0 268,0 404,-1 1,-171 -4,-416 -3,-586zm2221 2c-605,0 -1230,0 -1835,0 0,170 -1,414 -1,583 26,0 53,0 79,0 80,0 159,1 239,2 80,0 159,1 239,1 21,0 41,0 61,0 -1,940 -2,1799 -3,2739 194,-7 402,-14 596,-18 1,-935 1,-1789 2,-2724 205,-1 417,-1 622,-2 1,-166 1,-414 1,-581zm2040 -2c-551,0 -1103,0 -1654,0 0,1097 -1,2195 -1,3293 64,-1 129,-1 194,-1 132,0 265,1 396,2 0,-466 0,-891 -1,-1357 33,0 66,0 99,0 77,0 155,0 233,0 79,-1 158,-1 236,-1 80,0 160,0 238,1 0,-167 0,-415 0,-582 -74,-1 -149,-1 -225,-1 -82,0 -164,0 -246,1 -82,0 -163,0 -243,0 -31,0 -62,0 -92,0 0,-299 0,-468 0,-768 65,0 129,0 193,0 66,0 131,0 196,0 66,0 131,0 197,0 160,0 320,0 481,1 0,-167 0,-421 -1,-588zm387 2c1,1109 -4,2217 -3,3325 529,20 1085,41 1613,78 0,-171 0,-416 -1,-586 -334,-20 -682,-44 -1017,-58 -1,-949 4,-1810 2,-2759 -193,0 -401,0 -594,0zm2099 1c2,1146 4,2292 6,3438 194,15 395,31 588,48 1,-1161 3,-2324 0,-3486 -193,0 -401,0 -594,0zm1104 0c238,579 456,1160 697,1776 -251,591 -506,1178 -757,1745 208,20 423,50 630,74 149,-366 285,-647 434,-1022 149,400 284,708 432,1121 208,27 476,65 683,95 -251,-671 -525,-1369 -777,-2003 251,-596 507,-1164 768,-1786 -214,0 -435,0 -649,0 -162,384 -272,632 -427,998 -143,-381 -240,-628 -384,-998 -214,0 -435,0 -650,0z"/>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
<a class="home-card card-free-spotify-gift-cards" href="http://94660.giftcardrebel.co/94660/index.php?card=spotify">
  <div class="home-card-title">Free Spotify Gift Cards</div>
  <div class="home-card-front">
<svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgh15color{fill:#33cc33}]]></style></defs>
 <g>
  <path class="svgh15color" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg>
    <div class="home-card-logo"><svg width="100%" height="100%" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 16667 23611">
 <defs> <style type="text/css"> <![CDATA[.filspotify0 {fill:none} .filspotify1 {fill:white} ]]> </style> </defs> <g>
  <rect class="filspotify0" width="16667" height="23611"/>
  <g>
   <path class="filspotify1" d="M2732 6534l319 -388c221,185 452,302 733,302 220,0 354,-89 354,-235l0 -7c0,-139 -85,-210 -495,-317 -494,-128 -813,-267 -813,-763l0 -7c0,-453 358,-752 859,-752 357,0 662,114 911,317l-280 414c-217,-154 -431,-246 -638,-246 -207,0 -315,96 -315,217l0 7c0,164 105,218 529,328 497,132 778,314 778,749l0 7c0,495 -372,773 -901,773 -371,0 -746,-132 -1041,-399zm3076 -26c-274,0 -497,-249 -497,-557 0,-308 223,-558 497,-558 274,0 497,250 497,558 0,308 -223,557 -497,557zm136 -1541c-310,0 -499,112 -627,288l0 -252 -481 0 0 2449 490 0 0 -800c125,151 299,281 580,281 441,0 885,-345 885,-975l0 -7c0,-629 -425,-984 -847,-984zm1986 1554c-290,0 -526,-252 -526,-563 0,-312 236,-564 526,-564 290,0 525,252 525,564 0,311 -235,563 -525,563zm8 -1554c-574,0 -1009,442 -1009,987l0 7c0,544 432,979 1002,979 574,0 1000,-442 1000,-986l0 -7c0,-545 -423,-980 -993,-980zm2968 -490c0,166 -136,302 -302,302 -167,0 -302,-136 -302,-302 0,-167 135,-302 302,-302 166,0 302,135 302,302zm847 532l0 -94c0,-141 109,-205 234,-205 92,0 167,17 246,46l0 -428c-100,-32 -214,-54 -385,-54 -193,0 -319,50 -419,149 -100,100 -162,252 -162,462l0 120 -235 0 0 424 225 0 0 1460 501 0 0 -1459 391 0 587 1439c-49,115 -131,173 -222,173 -69,0 -180,-40 -249,-82l-176 374c135,80 323,129 514,129 337,0 498,-289 555,-437l776 -2013 -500 -1 -454 1284 -497 -1288 -255 0 -475 1zm-1390 3l481 0 0 1886 -481 0 0 -1886zm-1167 1344l0 -923 -235 0 0 -435 235 0 0 -498 487 0 0 498 491 0 0 435 -491 0 0 853c0,157 98,193 218,193 98,0 188,-33 265,-76l0 416c-112,68 -242,111 -422,111 -327,0 -548,-132 -548,-574z"/>
   <path class="filspotify1" d="M8333 8221c3096,0 5606,2509 5606,5605 0,3096 -2510,5606 -5606,5606 -3096,0 -5605,-2510 -5605,-5606 0,-3096 2509,-5605 5605,-5605zm4096 4519c-2,407 -428,656 -786,454 -242,-137 -490,-262 -749,-365 -513,-206 -1045,-345 -1589,-441 -379,-66 -760,-111 -1144,-134 -399,-24 -798,-26 -1197,-6 -458,24 -912,74 -1360,171 -165,36 -328,81 -492,124 -100,27 -199,31 -299,1 -218,-64 -369,-259 -375,-489 -7,-222 131,-430 347,-501 158,-52 320,-93 482,-130 402,-93 810,-151 1220,-188 437,-40 873,-53 1311,-40 1077,31 2133,188 3155,541 417,144 818,322 1199,545 136,79 227,191 262,346 8,36 10,74 15,112zm-5088 1255c-642,3 -1300,83 -1942,273 -105,31 -210,33 -312,-8 -167,-68 -276,-235 -270,-412 6,-185 119,-345 297,-400 181,-55 365,-103 550,-144 455,-101 916,-155 1382,-172 1003,-38 1982,91 2938,398 483,154 945,357 1382,617 22,13 43,26 65,39 227,139 254,419 146,598 -124,204 -382,267 -597,146 -121,-68 -241,-139 -365,-202 -567,-290 -1168,-477 -1793,-595 -480,-91 -965,-136 -1481,-138zm100 952c739,8 1462,108 2164,345 387,130 757,299 1108,508 30,18 61,36 89,57 142,108 178,303 87,456 -88,149 -276,209 -436,138 -32,-15 -63,-34 -93,-52 -595,-352 -1237,-571 -1919,-675 -419,-64 -840,-87 -1263,-70 -546,22 -1086,97 -1621,216 -54,12 -109,23 -164,23 -166,2 -305,-115 -334,-274 -31,-169 52,-327 207,-389 33,-13 67,-21 102,-29 437,-98 878,-172 1324,-210 249,-21 500,-30 749,-44z"/>
  </g>
  <rect class="filspotify0" width="16667" height="23611"/>
 </g>
</svg></div>
  </div>
  <div class="home-card-back"><svg width="100%" height="100%" version="1.0" style="fill-rule:evenodd; clip-rule:evenodd" viewBox="0 0 13889 19444">
 <defs><style type="text/css"><![CDATA[.svgshadow{fill:#50565B}]]></style></defs>
 <g>
  <path class="svgshadow" d="M604 0l12681 0c332,0 604,272 604,604l0 18237c0,332 -272,603 -604,603l-12681 0c-332,0 -604,-271 -604,-603l0 -18237c0,-332 272,-604 604,-604zm4546 1389l1100 0c0,-384 311,-695 695,-695 383,0 694,311 694,695l1100 0c222,0 404,182 404,405l0 0c0,223 -182,405 -404,405l-3589 0c-222,0 -405,-182 -405,-405l0 0c0,-223 183,-405 405,-405z"/>
 </g>
</svg></div>
</a>
    <div class="clear"></div>
  </div>
</div>

</div> <!-- END OF INNER -->
</div> <!-- END OF WRAPPER -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  
<script src="http://getgiftcards.org/resources/plugins.js" type="text/javascript"></script>
  

</body>
</html>
